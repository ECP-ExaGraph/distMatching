
// ***********************************************************************
//
//            Vite: A C++ library for distributed-memory graph b-Matching 
//                  using MPI-OpenMP
// 
//               Arif Khan (ariful.khan@pnnl.gov)
//               Mahantesh Halappanavar (hala@pnnl.gov)
//               Pacific Northwest National Laboratory       
//
//               Alex Pothen (apothen@purdue.edu)
//               Purdue University
//
// ***********************************************************************
//
//       Copyright (2017) Battelle Memorial Institute
//                      All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
// 1. Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
// COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
// BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
// ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// ************************************************************************
 
#include "bMatching.h"
#include <cstring>
#include <parallel/algorithm>
using namespace std;

#define MBUFLENGTH 1024*4
#define TBUFLENGTH 256*4

long long plock;
long long* pcount;
double** ptemp;
long long* endT;
long long* startT;
long long* bT;
Edge* eT;
long long* pivotT;

vector<vector<double> >psend;
vector<vector<double> >precv;

//vector<vector<float> >* psend;
//vector<vector<float> >psend1;
//vector<vector<float> >psend2;

__forceinline bool comparator(Edge left, Edge right) 
{ 
    return (left.weight > right.weight || (left.weight==right.weight && left.id > right.id)); 
}

bool nodeComp(long long i, long long j)
{
    return (((pivotT[i]-startT[i])/(bT[i]*1.0) > (pivotT[j]-startT[j])/(bT[j]*1.0))); 
}

bool nodeComp1(long long i, long long j)
{
    return (eT[endT[i]].weight>eT[endT[j]].weight);
    //return (eT[(endT[i]+startT[i])/2].weight > eT[(endT[j]+startT[j])/2].weight);
}

__forceinline bool nodeComp2(long long i, long long j)
{
    return (eT[startT[i]].weight>eT[startT[j]].weight);
}

bool insertMessage(DCSR* G, long long sid, long long vid, float weight, 
        long long type, long long tid)
{
    //assert(tid==0);
    assert(vid>=0 && vid<G->gnVer);
    long long count=pcount[tid];
    long long pid,id;
    if(count==TBUFLENGTH)
    {
        while(__sync_lock_test_and_set(&plock,1)==1);

        for(long long i=0;i<TBUFLENGTH;i=i+4)
        {
            pid=G->gnVer-G->nPerProc*(G->nProc-1);
            id=(long long)ptemp[tid][i+1]; 
            assert(pid>=0);

            if(id<pid)
                pid=0;
            else
                pid=((id-pid)/G->nPerProc)+1;    
            
            assert(pid>=0);
            if(pid>=G->nProc)
            {
                cout<<pid<<" "<<id<<" "<<G->nPerProc<<" "<<G->gnVer<<" "
                    <<(long long)ptemp[tid][i+1]<<" "<<(i+1)%4<<endl;
            }
            assert(pid<G->nProc);
            psend[pid].push_back(ptemp[tid][i]);
            psend[pid].push_back(ptemp[tid][i+1]);
            psend[pid].push_back(ptemp[tid][i+2]);
            psend[pid].push_back(ptemp[tid][i+3]);
        }
        __sync_lock_release(&plock);

        count=0;
    }

    assert(count>=0 && count+3<TBUFLENGTH);
    ptemp[tid][count]=sid;
    ptemp[tid][count+1]=vid;
    ptemp[tid][count+2]=weight;
    ptemp[tid][count+3]=type;
    count=count+4;
    pcount[tid]=count;

    return 1;
}

void bSuitorBPQD(DCSR* G, long long *b, int *nlocks, Node* S, long long* start, 
        long long* end, long long stepM, long long* sVer, long long npart, bool nsort, bool verbose) 
{

    long long n=G->nVer;
    long long m=G->nEdge;
    long long* ver=G->verPtr;
    Edge* verInd=G->verInd;
    long long* Q1=(long long*)_mm_malloc(n*sizeof(long long),64);
    long long* Q2=(long long*)_mm_malloc(n*sizeof(long long),64);
    long long* Qb1=(long long*)_mm_malloc(n*sizeof(long long),64);
    long long* Qb2=(long long*)_mm_malloc(n*sizeof(long long),64);
    long long* pivot=(long long*)_mm_malloc(n*sizeof(long long),64);
    long long* Qtemp;
    long long Qsize=n,Qindx=0,iter=1,tQsize,pQsize=n/npart,startQ,endQ;
    long long numThreads;
    long long addToGlobal=G->startNode;
    long long state=0,donecount=0;
    long long terminate=0,msize,count,vid;
    int pid;
    #pragma omp parallel
    numThreads=omp_get_num_threads();
    

    //cout<<"Processes: "<<G->nProc<<endl;
    //cout<<"Threads: "<<numThreads<<endl;
    double t1,t2,t3;
    long long propC=0,rejC=0,kickC=0,msgC=0,conC=0;
    
    #ifdef LBUF
    long long** TQ=(long long**)_mm_malloc(numThreads*sizeof(long long*),64);
    long long* tindx=(long long*)_mm_malloc(numThreads*sizeof(long long),64);

    for(long long i=0;i<numThreads;i++)
    {
        tindx[i]=0;
        TQ[i]=(long long*)_mm_malloc(BSIZE*sizeof(long long),64);
    }
    #endif

    ///////////// Data structures for messages
    plock=0;
    pcount=(long long*)_mm_malloc(numThreads*sizeof(long long),64);
    
    ptemp=(double**)_mm_malloc(numThreads*sizeof(double*),64);
    for(long long i=0;i<numThreads;i++)
    {    
        ptemp[i]=(double*)_mm_malloc(TBUFLENGTH*sizeof(double),64);
        pcount[i]=0;
    }
    
    vector<double> temp;
    for(long long i=0;i<G->nProc;i++)
    {
        psend.push_back(temp);
        precv.push_back(temp);
        
        //psend1.push_back(temp);
        //psend2.push_back(temp);
    }
    for(long long i=0;i<G->nProc;i++)
    {
        psend[i].clear();
        precv[i].clear();
    }

    double** ssize=(double**)_mm_malloc(G->nProc*sizeof(double*),64);
    double** rsize=(double**)_mm_malloc(G->nProc*sizeof(double*),64);
    for(long long i=0;i<G->nProc;i++)
    {
        ssize[i]=(double*)_mm_malloc(4*sizeof(double),64);
        rsize[i]=(double*)_mm_malloc(4*sizeof(double),64);
    }

    MPI_Request* ssreq=(MPI_Request*)_mm_malloc(G->nProc*sizeof(MPI_Request),64);
    MPI_Request* rsreq=(MPI_Request*)_mm_malloc(G->nProc*sizeof(MPI_Request),64);
    MPI_Request* sdreq=(MPI_Request*)_mm_malloc(G->nProc*sizeof(MPI_Request),64);
    MPI_Request* rdreq=(MPI_Request*)_mm_malloc(G->nProc*sizeof(MPI_Request),64);
    MPI_Status* status=(MPI_Status*)_mm_malloc(G->nProc*sizeof(MPI_Status),64);
    ///////////////////////////////////////////////

    //cout<<"Memory Allocation done..!!"<<endl; 
    if(verbose)
        t1=omp_get_wtime();

    #ifdef DYN
        #pragma omp parallel for schedule(dynamic,CHUNK)
    #else
        #pragma omp parallel for schedule(static, CHUNK)
    #endif
    for(long long i=0;i<n;i++)  
    {
        nlocks[i]=0;            // Initialize locks
        start[i]=ver[i];    // Adj List start pointer
        end[i]=custom_sort(verInd,ver[i],ver[i+1],stepM*b[i]);
        
        Q1[i]=i;
        Qb1[i]=b[i];
        Qb2[i]=0;
    }
    
    #ifdef DYN
        #pragma omp parallel for schedule(dynamic,CHUNK)
    #else
        #pragma omp parallel for schedule(static, CHUNK)
    #endif
    for(long long i=0;i<G->gnVer;i++)  
    {
        if(i>=G->startNode && i<=G->endNode)
        {
            S[i].curSize=0;                 // current matching=0
            S[i].maxSize=b[i-G->startNode]; // maximum matching=b
            S[i].minEntry.id=-1;
            S[i].minEntry.weight=0.0;
        }
        else
        {
            S[i].curSize=0;         // current matching=0
            S[i].maxSize=1;         // maximum matching=1, Ghost node
            S[i].minEntry.id=-1;
            S[i].minEntry.weight=0.0;
        }
    }
    if(verbose)    
        t2=omp_get_wtime();
    
    pivotT=pivot;
    endT=end;
    startT=start;
    bT=b;
    eT=verInd;
    //__gnu_parallel::sort(&Q1[0],&Q1[Qsize],nodeComp2);

    //MPI_Barrier(MPI_COMM_WORLD);
    //cout<<"Initialization Done..: "<<Qsize<<endl;
    //psend=&psend1;
    
    //while(true)
    //{
        while(Qsize>0 || donecount !=(G->nProc-1))
        {
            //cout<<"Qsize: "<<Qsize<<endl;
            //if(iter<=3)
            if(nsort)
                __gnu_parallel::sort(&Q1[0],&Q1[Qsize],nodeComp2);
            //iter++;
            
            startQ=0;
            endQ=0;
            while(true)
            {
                startQ=endQ;
                endQ=startQ+pQsize;
                if(endQ>=Qsize)
                    endQ=Qsize;
                #pragma omp parallel for schedule(guided,CHUNK)		
                for(long long i=startQ;i<endQ;i++) 
                {
                    float min_w,heaviest,weight;
                    long long  min_idx,bVer,current,gcurrent,next_vertex,sold,eold,skip;
                    long long  partnerIdx,partner,lid,gid,y,j,done,tid=0;
                    long long excess,sstep;
                    
                    tid=omp_get_thread_num();
                    //assert(tid==0);
                    
                    #ifdef LBUF
                    long long* LQ=TQ[tid];
                    long long* lindx=&tindx[tid];
                    #endif
                    
                    current=Q1[i];
                    gcurrent=current+addToGlobal;
                    assert(current>=0 && current<n);
                    bVer=Qb1[current];
                    sstep=sVer[current];
                    //sstep=2;
                    Qb1[current]=0;

                    /// Super stepping logic
                    if(bVer>sstep)
                    {
                        excess=bVer-sstep;
                        bVer=sstep;

                        if(end[current]!=-1)
                        {
                            #ifdef LBUF
                            if(__sync_fetch_and_add(&Qb2[current],excess)==0)
                            {   
                                LQ[(*lindx)]=current;
                                (*lindx)++;
                                if((*lindx)==BSIZE)
                                {
                                    long long start=__sync_fetch_and_add(&Qindx,BSIZE);
                                    long long count=0;
                                    for(long long k=start;k<start+BSIZE;k++)
                                    {    
                                        Q2[k]=LQ[count];
                                        count++;
                                    }
                                    
                                    (*lindx)=0;
                                }
                            }
                            #else
                            if(__sync_fetch_and_add(&Qb2[current],excess)==0)
                               Q2[__sync_fetch_and_add(&Qindx,1)]=current;
                            #endif
                        }

                    }
                    //cout<<"Node: "<<i<<endl;
                    while(bVer>0)
                    { // For Each vertex we want to find bVer=b partners

                        //cout<<i<<" "<<bVer<<endl;
                        partner=-1;
                        heaviest=0.0;
                        next_vertex=-1;
                        done=1;

                        sold=start[current];
                        eold=end[current];
                        j=sold;
                        assert(j>=0); 
                        //assert(j<m);
                        while(j<end[current]) // Loop over neighbors of the current vertex 
                        {    
                            //cout<<"neighbor: "<<bVer<<" "<<j<<" "<<end[current]<<endl;
                            y = verInd[j].id;               // y is the neighbor of the current vertex
                            assert(y>=0 && y<G->gnVer);
                            weight=verInd[j].weight;        // weight is w(current,y)
                            if(weight<=0)
                            {
                                heaviest=-1.0;
                                break;
                            }
                            min_w=S[y].minEntry.weight;

                            if(weight <=0 || min_w > weight)
                            {
                                j++;
                                continue;
                            }
                            
                            //// Adding to heap
                            if(y>=G->startNode && y<=G->endNode) // partner is local
                            {
                                gid=y;   // saving the global id of partner
                                lid=y-addToGlobal; // computing the local id of partner

                                while(__sync_lock_test_and_set(&nlocks[lid],1)==1);
                                               
                                min_w=S[y].minEntry.weight;
                                min_idx=S[y].minEntry.id;

                                if((min_w > weight) || (weight == min_w && gcurrent < min_idx))
                                {    
                                    __sync_lock_release(&nlocks[lid]);
                                    j++;
                                }
                                else
                                {
                                    heaviest=weight;
                                    S[y].AddHeap(heaviest,gcurrent);    
                                                
                                    __sync_lock_release(&nlocks[lid]);
                                    start[current]=j+1;

                                    if(min_idx==-1)
                                        break;
                                    
                                    /// Check if dislodged is local
                                    if(min_idx>=G->startNode && min_idx<=G->endNode)
                                    {    
                                        gid=min_idx;   
                                        lid=min_idx-addToGlobal;
                                       
                                        assert(lid>=0);
                                        if(end[lid]!=-1)
                                        {
                                            #ifdef LBUF
                                            if(__sync_fetch_and_add(&Qb2[lid],1)==0)
                                            {   
                                                LQ[(*lindx)]=lid;
                                                (*lindx)++;
                                                if((*lindx)==BSIZE)
                                                {
                                                    long long start=__sync_fetch_and_add(&Qindx,BSIZE);
                                                    long long count=0;
                                                    for(long long k=start;k<start+BSIZE;k++)
                                                    {    
                                                        Q2[k]=LQ[count];
                                                        count++;
                                                    }
                                                    
                                                    (*lindx)=0;
                                                }
                                            }
                                            #else
                                            if(__sync_fetch_and_add(&Qb2[lid],1)==0)
                                               Q2[__sync_fetch_and_add(&Qindx,1)]=lid;
                                            #endif
                                        }
                                    } 
                                    else
                                    {
                                        
                                       // KICK Message 
                                       lid=y-addToGlobal;
                                       while(__sync_lock_test_and_set(&nlocks[lid],1)==1);
                                       insertMessage(G,y,min_idx,
                                                S[y].minEntry.weight,S[y].minEntry.id,tid);
                                       __sync_lock_release(&nlocks[lid]);
                                        
                                       if(verbose)
                                        __sync_fetch_and_add(&kickC,1);
                                    }
                                    
                                    break; //breaking from neighbor search
                                }
                            }
                            else
                            {
                                //if(min_w > weight)
                                    //j++;
                                //else
                                {
                                
                                    while(__sync_lock_test_and_set(&S[y].curSize,1)==1);
                                    S[y].minEntry.weight=weight;
                                    S[y].minEntry.id=gcurrent;
                                    __sync_lock_release(&S[y].curSize);
                                    
                                    assert(y<G->gnVer);
                                    insertMessage(G,gcurrent,y,weight,-2,tid);    
                                    // ADD To The proposal queue
                                    heaviest=weight;
                                    start[current]=j+1;
                                    
                                    if(verbose)
                                        __sync_fetch_and_add(&propC,1);
                                    
                                    break;
                                }
                            }

                        }   // while(j<end[current])

                        //cout<<"More neighbor"<<endl;
                        if(heaviest<=0)
                        {
                            start[current]=j;
                            if(end[current]<ver[current+1] && heaviest==0)
                            {
                                end[current]=custom_sort(verInd,start[current],ver[current+1],
                                        stepM*b[current]);
                                done=0;
                            }
                            else
                                end[current]=-1;
                        }
                      
                        if(end[current]==-1)  // if the vertex is alive
                            break;     // Do not forget to decrease bVer ...!!
                        else
                            if(next_vertex!=current && done==1)
                                bVer--;
                    } // while(bVer)
                } // loop over vertices
                   
                /*#pragma omp parallel for schedule(guided,CHUNK)		
                for(long long i=tQsize;i<Qsize;i++) 
                {
                    long long  bVer,current,tid;
                    
                    tid=omp_get_thread_num();
                    //assert(tid==0);
                    
                    #ifdef LBUF
                    long long* LQ=TQ[tid];
                    long long* lindx=&tindx[tid];
                    #endif
                    
                    current=Q1[i];
                    assert(current>=0 && current<n);
                    bVer=Qb1[current];
                    Qb1[current]=0;

                    /// Super stepping logic

                    if(end[current]!=-1)
                    {
                        #ifdef LBUF
                        if(__sync_fetch_and_add(&Qb2[current],bVer)==0)
                        {   
                            LQ[(*lindx)]=current;
                            (*lindx)++;
                            if((*lindx)==BSIZE)
                            {
                                long long start=__sync_fetch_and_add(&Qindx,BSIZE);
                                long long count=0;
                                for(long long k=start;k<start+BSIZE;k++)
                                {    
                                    Q2[k]=LQ[count];
                                    count++;
                                }
                                
                                (*lindx)=0;
                            }
                        }
                        #else
                        if(__sync_fetch_and_add(&Qb2[current],excess)==0)
                           Q2[__sync_fetch_and_add(&Qindx,1)]=current;
                        #endif
                    }
                }*/
                
                ///////////// Add the rest messages to process message queues
                for(long long i=0;i<numThreads;i++)
                {
                    count=pcount[i];
                    long long tpid;
                    for(long long j=0;j<count;j=j+4)
                    {
                        tpid=G->gnVer-G->nPerProc*(G->nProc-1);
                        vid=(long long)ptemp[i][j+1];

                        if(vid<tpid)
                            pid=0;
                        else
                            pid=((vid-tpid)/G->nPerProc)+1;    
                        
                        /*(*psend)[pid].push_back(ptemp[i][j]);
                        (*psend)[pid].push_back(ptemp[i][j+1]);
                        (*psend)[pid].push_back(ptemp[i][j+2]);
                        (*psend)[pid].push_back(ptemp[i][j+3]);*/

                        psend[pid].push_back(ptemp[i][j]);
                        psend[pid].push_back(ptemp[i][j+1]);
                        psend[pid].push_back(ptemp[i][j+2]);
                        psend[pid].push_back(ptemp[i][j+3]);
                    }
                    pcount[i]=0;
                }


                //cout<<"(Process "<<G->rank<<"): "<<"Sending size messages"<<endl;
                for(int i=0;i<G->nProc;i++)
                {
                    if(i==G->rank)
                    {  
                        ssreq[i]=MPI_REQUEST_NULL;
                        continue;
                    }
                    /// send size messages

                    
                    /*if((*psend)[i].size()>0)
                        msize=(*psend)[i].size();
                    else
                        msize=4;*/

                    if(psend[i].size()>0)
                        msize=psend[i].size();
                    else
                        msize=4;
                    //cout<<"Sending size: "<<msize<<endl;
                    ssize[i][2]=msize;
                    ssize[i][3]=-1;
                    MPI_Isend(&ssize[i][0],4,MPI_DOUBLE,i,10,MPI_COMM_WORLD,&ssreq[i]);
                    
                    if(verbose)
                    {
                        msize=msize/4;
                        __sync_fetch_and_add(&msgC,msize);
                        __sync_fetch_and_add(&conC,1);
                    }
                }

                //cout<<"(Process "<<G->rank<<"): "<<"Sending Data messages"<<endl;
                // send data message
                for(int i=0;i<G->nProc;i++)
                {
                    if(i==G->rank)
                    {  
                        sdreq[i]=MPI_REQUEST_NULL;
                        continue;
                    }

                    MPI_Waitany(G->nProc,ssreq,&pid,status);

                    /*if((*psend)[pid].size()>0)
                    {
                        msize=(*psend)[pid].size();
                        //cout<<"Sending DATA to: "<<pid<<endl;
                        MPI_Isend(&((*psend)[pid][0]),msize,MPI_DOUBLE,pid,11,MPI_COMM_WORLD,&sdreq[pid]);
                    }*/
                    if(psend[pid].size()>0)
                    {
                        msize=psend[pid].size();
                        //cout<<"Sending DATA to: "<<pid<<endl;
                        MPI_Isend(&(psend[pid][0]),msize,MPI_DOUBLE,pid,11,MPI_COMM_WORLD,&sdreq[pid]);
                        
                        if(verbose)
                            __sync_fetch_and_add(&conC,1);

                    }
                    else // Termination message
                    {
                        //cout<<"Sending TERM to:"<<pid<<endl;
                        terminate++;
                        if(state==0)
                            ssize[pid][3]=-4;
                        else
                            ssize[pid][3]=-5;
                        MPI_Isend(&ssize[pid][0],4,MPI_DOUBLE,pid,11,MPI_COMM_WORLD,&sdreq[pid]);
                    }
                }
                
                //cout<<"(Process "<<G->rank<<"): "<<"Recieving size messages"<<endl;
                for(int i=0;i<G->nProc;i++)
                {
                    if(i==G->rank)
                    {  
                        rsreq[i]=MPI_REQUEST_NULL;
                        continue;
                    }
                    MPI_Irecv(&rsize[i][0],4,MPI_DOUBLE,i,10,MPI_COMM_WORLD,&rsreq[i]);
                }

                //cout<<"(Process "<<G->rank<<"): "<<"Recieving data messages"<<endl;
                for(int i=0;i<G->nProc;i++)
                {
                    // Do waitany on size request and call data message for that process
                    if(i==G->rank)
                    {  
                        rdreq[i]=MPI_REQUEST_NULL;
                        continue;
                    }
                    
                    MPI_Waitany(G->nProc,rsreq,&pid,status);
                    msize=rsize[pid][2];
                    precv[pid].resize(msize);
                    
                    MPI_Irecv(&precv[pid][0],msize,MPI_DOUBLE,pid,11,MPI_COMM_WORLD,&rdreq[pid]);
                }
                
                /// We need to clear all the send buffer
                /// We can avoid this Waitall() by using another set of send buffers
                
                MPI_Waitall(G->nProc,sdreq,status);
                
                /*if(iter%2==1)
                    psend=&psend1;
                else
                    psend=&psend2;
                
                for(int i=0;i<G->nProc;i++)
                    (*psend)[i].clear();*/
                
                for(int i=0;i<G->nProc;i++)
                    psend[i].clear();

                //cout<<"(Process "<<G->rank<<"): "<<"Processing messages.."<<endl;
                for(int i=0;i<G->nProc;i++)
                {
                    // Do waitany on data request and process parallely
                    if(i==G->rank)
                        continue;
                    MPI_Waitany(G->nProc,rdreq,&pid,status);
                    //pid=i;
                    
                    #pragma omp parallel for
                    for(long long k=0;k<(long long)rsize[pid][2];k=k+4)
                    {
                        
                        long long gcurrent=precv[pid][k];
                        long long current=gcurrent-addToGlobal;
                        long long y=precv[pid][k+1];
                        long long lid=y-addToGlobal;
                        float weight=precv[pid][k+2];
                        long long mtype=precv[pid][k+3];
                        long long min_idx=-1;
                        long long gid;
                        float heaviest=0.0,min_w; 
                        long long tid=omp_get_thread_num();
                        #ifdef LBUF
                        long long* LQ=TQ[tid];
                        long long* lindx=&tindx[tid];
                        #endif
                        if(mtype<0)
                        {    
                            switch(mtype)
                            {
                                case -1: // SIZE
                                    cout<<"Size message should not show up here..!!"<<endl;
                                    break;
                                case -2: // PROPOSAL
                                     
                                    while(__sync_lock_test_and_set(&nlocks[lid],1)==1);
                                                   
                                    min_w=S[y].minEntry.weight;
                                    min_idx=S[y].minEntry.id;

                                    if((min_w > weight) || (weight == min_w && gcurrent < min_idx))
                                    {    
                                       
                                        insertMessage(G,y,gcurrent,min_w,min_idx,tid); 
                                        // ADD REJECT MESSAGE
                                       
                                        __sync_lock_release(&nlocks[lid]);
                                        
                                        if(verbose)
                                        __sync_fetch_and_add(&rejC,1);
                                    }
                                    else
                                    {
                                        heaviest=weight;
                                        S[y].AddHeap(heaviest,gcurrent);    
                                                    
                                        __sync_lock_release(&nlocks[lid]);

                                        if(min_idx==-1)
                                            break;
                                        
                                        /// Check if dislodged is local
                                        if(min_idx>=G->startNode && min_idx<=G->endNode)
                                        {    
                                            gid=min_idx;   
                                            lid=min_idx-addToGlobal;
                                            
                                            if(end[lid]!=-1)
                                            {
                                                #ifdef LBUF
                                                if(__sync_fetch_and_add(&Qb2[lid],1)==0)
                                                {   
                                                    LQ[(*lindx)]=lid;
                                                    (*lindx)++;
                                                    if((*lindx)==BSIZE)
                                                    {
                                                        long long start=__sync_fetch_and_add(&Qindx,BSIZE);
                                                        long long count=0;
                                                        for(long long k=start;k<start+BSIZE;k++)
                                                        {    
                                                            Q2[k]=LQ[count];
                                                            count++;
                                                        }
                                                        
                                                        (*lindx)=0;
                                                    }
                                                }
                                                #else
                                                if(__sync_fetch_and_add(&Qb2[lid],1)==0)
                                                   Q2[__sync_fetch_and_add(&Qindx,1)]=lid;
                                                #endif
                                            }
                                        }
                                        else
                                        {
                                           //insertMessage(G,y,min_idx,
                                                    //S[y].minEntry.weight,S[y].minEntry.id,tid);
                                            
                                           lid=y-addToGlobal;
                                           while(__sync_lock_test_and_set(&nlocks[lid],1)==1);
                                           insertMessage(G,y,min_idx,
                                                    S[y].minEntry.weight,S[y].minEntry.id,tid);
                                           __sync_lock_release(&nlocks[lid]);

                                            if(verbose)
                                                __sync_fetch_and_add(&kickC,1);
                                        }
                                    }
                                    break;

                                case -3: // UPDATE
                                    break;
                                case -4: // TERMINATE
                                    __sync_fetch_and_add(&terminate,1);
                                    break;
                                case -5: // DONE
                                    __sync_fetch_and_add(&terminate,1);
                                    __sync_fetch_and_add(&donecount,1);
                                    break;

                            }
                        }
                        else // REJECT OR KICKED MESSAGE
                        {
                            
                            while(__sync_lock_test_and_set(&S[gcurrent].curSize,1)==1);
                            S[gcurrent].minEntry.weight=weight;
                            S[gcurrent].minEntry.id=mtype;
                            __sync_lock_release(&S[gcurrent].curSize);

                            
                            if(end[lid]!=-1)
                            {
                                #ifdef LBUF
                                if(__sync_fetch_and_add(&Qb2[lid],1)==0)
                                {   
                                    LQ[(*lindx)]=lid;
                                    (*lindx)++;
                                    if((*lindx)==BSIZE)
                                    {
                                        long long start=__sync_fetch_and_add(&Qindx,BSIZE);
                                        long long count=0;
                                        for(long long k=start;k<start+BSIZE;k++)
                                        {    
                                            Q2[k]=LQ[count];
                                            count++;
                                        }
                                        
                                        (*lindx)=0;
                                    }
                                }
                                #else
                                if(__sync_fetch_and_add(&Qb2[lid],1)==0)
                                   Q2[__sync_fetch_and_add(&Qindx,1)]=lid;
                                #endif
                            }
                        }
                    } /// END FOR current process
                }/// END FOR all process 
                #ifdef LBUF
                #pragma omp parallel for
                for(long long i=0;i<numThreads;i++)
                { 
                    long long* LQ=TQ[i];
                    long long* lindx=&tindx[i];
                    if((*lindx)>0)
                    {    
                        long long start=__sync_fetch_and_add(&Qindx,(*lindx));
                        long long count=0;
                        for(long long k=start;k<start+(*lindx);k++)
                        {        
                            Q2[k]=TQ[i][count];
                            count++;
                        }
                        (*lindx)=0;
                    }
                }
            
            
                if(endQ==Qsize)
                    break;
            }//// END WHILE NODE STEPPING
            #endif
            Qtemp=Q1;
            Q1=Q2;
            Q2=Qtemp;
            Qtemp=Qb1;
            Qb1=Qb2;
            Qb2=Qtemp;
            Qsize=Qindx;
            Qindx=0;
            
            pivotT=pivot;
            endT=end;
            startT=start;
            bT=b;
            eT=verInd;
            //__gnu_parallel::sort(&Q1[0],&Q1[Qsize],nodeComp2);

            
            /////////// Termination criteria... a bit critical
            if(terminate==(2*G->nProc-2))
            {    
                if(state==0)
                {    
                    //cout<<"Terminate: "<<G->rank<<" "<<terminate<<endl;
                    state=1;
                    terminate=0;
                    donecount=0;
                }
                else
                {    
                    if(donecount==(G->nProc-1))
                        break;
                    else
                    {    
                        terminate=0;
                        donecount=0;
                    }
                }
            }
            else
            {
                state=0;
                donecount=0;
                terminate=0;
            }
        }
        
        //MPI_Barrier(MPI_COMM_WORLD);
        //MPI_Waitall(G->nProc,sdreq,status);
    //}// END WHILE all done
    
    if(G->rank==0)
        cout<<"Matching Done....!!"<<endl;
    
    if(verbose)
    {
        double* lcounts=(double*)_mm_malloc(5*sizeof(double),64);
        double* gcounts=(double*)_mm_malloc(5*sizeof(double),64);
            
        lcounts[0]=msgC;
        lcounts[1]=propC;
        lcounts[2]=rejC;
        lcounts[3]=kickC;
        lcounts[4]=conC;

        MPI_Reduce(&lcounts[0],&gcounts[0],5,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);

        long long giga=1024*1024*1024;
        if(G->rank==0)
        {
            long long data=(long long)((gcounts[0]*32)/giga);
            double bandwidth=data/(23.7*1024);

            cout<<"# of communications: "<<(long long)gcounts[4]<<endl;
            cout<<"# of data xfer: "<<data<<" GB in "<<bandwidth<<" sec"<<endl;
            cout<<"# of messages: "<<(long long)gcounts[0]<<endl;
            cout<<"# of proposals: "<<(long long)gcounts[1]<<endl;
            cout<<"# of rejections: "<<(long long)gcounts[2]<<endl;
            cout<<"# of annullements: "<<(long long)gcounts[3]<<endl;
        }
        _mm_free(lcounts);
        _mm_free(gcounts);
    }
    
    _mm_free(Q1);
    _mm_free(Q2);
    _mm_free(Qb1);
    _mm_free(Qb2);
    _mm_free(tindx);
    _mm_free(pcount);
    _mm_free(ssreq);
    _mm_free(rsreq);
    _mm_free(sdreq);
    _mm_free(rdreq);
    _mm_free(status);

    for(long long i=0;i<G->nProc;i++)
    {
        _mm_free(ssize[i]);
        _mm_free(rsize[i]);
    }
    for(long long i=0;i<numThreads;i++)
    {
        _mm_free(TQ[i]);
        _mm_free(ptemp[i]);
    }
    
    _mm_free(ptemp);
    _mm_free(TQ);

}// end of bSuitor
