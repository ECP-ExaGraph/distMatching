
// ***********************************************************************
//
//            Vite: A C++ library for distributed-memory graph b-Matching 
//                  using MPI-OpenMP
// 
//               Arif Khan (ariful.khan@pnnl.gov)
//               Mahantesh Halappanavar (hala@pnnl.gov)
//               Pacific Northwest National Laboratory       
//
//               Alex Pothen (apothen@purdue.edu)
//               Purdue University
//
// ***********************************************************************
//
//       Copyright (2017) Battelle Memorial Institute
//                      All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
// 1. Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
// COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
// BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
// ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// ************************************************************************
 
#include "bMatching.h"
#include "mtxReader.h"
#include <stdlib.h>
#include <time.h>
#include <getopt.h>
#include <float.h>
#include <math.h>
using namespace std;

bool distGraphReading(DCSR* DG, char* pf, char* bf, int b, int s, unsigned long np, MPI_Comm comm)
{
    int rank;
    MPI_Status stat;
    MPI_Comm_rank(comm, &rank);	
    
    long long start,offset,count;
    long long nodePerProcess;
    long long gnver,gnedge,maxdeg;

    ifstream inf;
    inf.open(pf,ios::in|ios::binary);
    
    if(inf.is_open())
    {
        inf.read((char*)&gnver,sizeof(long long));
        inf.read((char*)&gnedge,sizeof(long long));
        inf.read((char*)&maxdeg,sizeof(long long));

        nodePerProcess=ceil(gnver/(np*1.0));
        
        if(rank==0) // Extra adjustment for the master node because it will have the excess nodes
        {
            DG->gnVer=gnver;
            DG->gnEdge=gnedge;
            DG->nVer=gnver-(nodePerProcess*(np-1));

            //Copy vertex Pointers
            DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
            //cout<<"Rank 0 initially :"<<inf.tellg()<<endl;
            inf.read((char*)&DG->verPtr[0],sizeof(long long)*(DG->nVer+1));
            inf.seekg((3+gnver+1)*sizeof(long long),inf.beg);
            //cout<<"Rank 0, after verPtr:"<<DG->nVer<<" "<<inf.tellg()<<endl;

            DG->nEdge=DG->verPtr[DG->nVer];

            long long* verInd=(long long*)_mm_malloc(DG->nEdge*sizeof(long long),64);
            float* verWt=(float*)_mm_malloc(DG->nEdge*sizeof(float),64);

            inf.read((char*)&verInd[0],sizeof(long long)*DG->nEdge);
            inf.seekg((3+gnver+1+gnedge)*sizeof(long long),inf.beg);
            //cout<<"Rank 0, after verInd:"<<DG->nEdge<<" "<<inf.tellg()<<endl;
            inf.read((char*)&verWt[0],sizeof(float)*DG->nEdge);

            DG->nProc=np;
            DG->rank=rank;
            DG->startNode=0;
            DG->endNode=gnver-(nodePerProcess*(np-1))-1;
            DG->nPerProc=nodePerProcess;
            
            //Copy Edge Indices and Edge Weights
            DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
            
            #pragma omp parallel for
            for(long long i=0;i<DG->nEdge;i++)
            {
                DG->verInd[i].id=verInd[i];
                DG->verInd[i].weight=(float)verWt[i];
            }
            _mm_free(verInd);
            _mm_free(verWt);
            
            //Copy bV value
            DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
            
            if(b>0)
            {    
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                {    
                    long long deg=DG->verPtr[i+1]-DG->verPtr[i];
                    if(deg>b)
                        //DG->bVer[i]=b; //Matching
                        DG->bVer[i]=deg-b; // Edge Cover
                    else
                    {
                        /*if(deg>0)
                            DG->bVer[i]=deg;
                        else
                            DG->bVer[i]=1; */ //Matching
                        
                        DG->bVer[i]=1; // Edge Cover
                    }
                }
            }
            else
            {
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                {    
                    long long deg=DG->verPtr[i+1]-DG->verPtr[i];         
                    if(deg<=2)
                        DG->bVer[i]=1;
                    else
                        DG->bVer[i]=(long long)(deg/(log2(deg)*1.0));
                }
            }
            
            //Copy sV value
            DG->sVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
            
            if(s>0)
            {    
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                    DG->sVer[i]=s;
            }
            else
            {
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                {    
                    if(DG->bVer[i]>=1)
                        DG->sVer[i]=DG->bVer[i]/2;
                    else
                        DG->sVer[i]=1;
                }
            }
        }
        else   // for other nodes
        {
            start=gnver-(nodePerProcess*(np-1));
            start=start+(rank-1)*nodePerProcess;
                
            DG->gnVer=gnver;
            DG->gnEdge=gnedge;
            DG->nVer=nodePerProcess;
            DG->nProc=np;
            DG->rank=rank;
            DG->nPerProc=nodePerProcess;
            
            
            //Copy vertex Pointers
            DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
            inf.seekg((3+start)*sizeof(long long),inf.beg);
            //if(rank==5)
                //cout<<"Rank 5 initially :"<<start<<" "<<inf.tellg()<<endl;
            inf.read((char*)&DG->verPtr[0],sizeof(long long)*(DG->nVer+1));

            offset=DG->verPtr[0];
            
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer+1;i++)
                DG->verPtr[i]=DG->verPtr[i]-offset;
            
            DG->startNode=start;
            DG->endNode=start+nodePerProcess-1;
            
            //Copy Edge Indices and Edge Weights
            DG->nEdge=DG->verPtr[DG->nVer];
            DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
            
            long long* verInd=(long long*)_mm_malloc(DG->nEdge*sizeof(long long),64);
            float* verWt=(float*)_mm_malloc(DG->nEdge*sizeof(float),64);
            
            inf.seekg((3+gnver+1+offset)*sizeof(long long),inf.beg);

            //if(rank==5)
                //cout<<"Rank 5 after verptr :"<<offset<<" "<<inf.tellg()<<endl;

            inf.read((char*)&verInd[0],sizeof(long long)*DG->nEdge);
            inf.seekg((3+gnver+1+gnedge)*sizeof(long long),inf.beg);
            inf.seekg(offset*sizeof(float),inf.cur);

            //if(rank==5)
                //cout<<"Rank 5 after verind :"<<DG->nEdge<<" "<<inf.tellg()<<endl;
            inf.read((char*)&verWt[0],sizeof(float)*DG->nEdge);

            #pragma omp parallel for
            for(long long i=0;i<DG->nEdge;i++)
            {    
                DG->verInd[i].id=verInd[i];
                DG->verInd[i].weight=verWt[i];
            }
            _mm_free(verInd);
            _mm_free(verWt);
            
                /// recieve the b values from the master..
            DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
            if(b>0)
            {    
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                {    
                    long long deg=DG->verPtr[i+1]-DG->verPtr[i];
                    if(deg>b)
                        //DG->bVer[i]=b; //Matching
                        DG->bVer[i]=deg-b; // Edge Cover
                    else
                    {
                        if(deg>0)
                            DG->bVer[i]=deg;
                        else
                            DG->bVer[i]=1; // Matching
                        
                        //DG->bVer[i]=1; // Edge Cover
                    }
                }
            }
            else
            {
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                {    
                    long long deg=DG->verPtr[i+1]-DG->verPtr[i];         
                    if(deg<=2)
                        DG->bVer[i]=1;
                    else
                        DG->bVer[i]=(long long)(deg/(log2(deg)*1.0));
                }
            }
            
            //Copy sV value
            DG->sVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
            
            if(s>0)
            {    
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                    DG->sVer[i]=s;
            }
            else
            {
                #pragma omp parallel for
                for(long long i=0;i<DG->nVer;i++)
                {    
                    if(DG->bVer[i]>=1)
                        DG->sVer[i]=DG->bVer[i]/2;
                    else
                        DG->sVer[i]=1;
                }
            }
         }
    
    
    }

    inf.close();
    return 1;

}
/*bool distGraphReadingChunk(DCSR* DG, char* pf, char* bf, unsigned long np, MPI_Comm comm)
{
    int rank;
    MPI_Status stat;
    MPI_Comm_rank(comm, &rank);	
    
    TCSR G;
    //G.readCSRbin(pf);
    ifstream inf;
    inf.open(pf,ios::in|ios::binary);
    if(!inf.is_open())
        return false;
    
    inf.read((char*)&G.nVer,sizeof(long long));
    inf.read((char*)&G.nEdge,sizeof(long long));
    inf.read((char*)&G.maxDeg,sizeof(long long));

    
    long long start,offset,count;
    long long nodePerProcess=ceil(G.nVer/(np*1.0));;
    
    if(rank==0) // Extra adjustment for the master node because it will have the excess nodes
    {
    	DG->gnVer=G.nVer;
        DG->gnEdge=G.nEdge;
        DG->nVer=G.nVer-(nodePerProcess*(np-1));
        DG->nEdge=G.verPtr[DG->nVer];
        DG->nProc=np;
        DG->rank=rank;
        DG->startNode=0;
        DG->endNode=G.nVer-(nodePerProcess*(np-1))-1;
        DG->nPerProc=nodePerProcess;
        
        //// Master will generate b values and then send around
        long long *bV=(long long*)_mm_malloc(G.nVer*sizeof(long long),64);
        if(bf==NULL)
        {
            #pragma omp parallel for
            for(long long i=0;i<G.nVer;i++)
            {
                //bV[i]=5;
                
                long long deg=(long long)sqrt(G.verPtr[i+1]-G.verPtr[i]);         
                if(deg<=1)
                    bV[i]=1;
                else
                    bV[i]=rand()%deg+1;
            }
        }
        
        //Copy vertex Pointers
        G.verPtr=(long long*)_mm_malloc((G.nVer+1)*sizeof(long long),64);
        inf.read((char*)&G.verPtr[0],sizeof(long long)*(G.nVer+1));
        DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
        
        #pragma omp parallel for
        for(long long i=0;i<=DG->nVer;i++)
            DG->verPtr[i]=G.verPtr[i];
        _mm_free(G.verPtr);
        
        //Copy Edge Indices and Edge Weights
        G.verInd=(long long*)_mm_malloc(G.nEdge*sizeof(long long),64);
        inf.read((char*)&G.verInd[0],sizeof(long long)*G.nEdge);
        DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
        
        #pragma omp parallel for
        for(long long i=0;i<DG->nEdge;i++)
            DG->verInd[i].id=G.verInd[i];
        
        _mm_free(G.verInd);
        
        G.verWt=(float*)_mm_malloc(G.nEdge*sizeof(float),64);
        inf.read((char*)&G.verWt[0],sizeof(float)*G.nEdge);
        
        #pragma omp parallel for
        for(long long i=0;i<DG->nEdge;i++)
            DG->verInd[i].weight=(float)G.verWt[i];
       
        _mm_free(G.verWt);
       
        
        //Copy bV value
        DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        
        
        // store b values for master
        #pragma omp parallel for
        for(long long i=0;i<DG->nVer;i++)
            DG->bVer[i]=bV[i];
        
        // send the rest of the b values
        start=G.nVer-(nodePerProcess*(np-1));
    	for(int i=1;i<np;i++)
        {
            MPI_Send(&bV[start],nodePerProcess,MPI_LONG_LONG,i,1,comm);
            start=start+nodePerProcess; // adjusting the start
        }
        
        _mm_free(bV);
    }
    else   // for other nodes
    {
        start=G.nVer-(nodePerProcess*(np-1));
        start=start+(rank-1)*nodePerProcess;
        offset=G.verPtr[start];
    		
        DG->gnVer=G.nVer;
        DG->gnEdge=G.nEdge;
        DG->nVer=nodePerProcess;
        DG->nProc=np;
        DG->rank=rank;
        DG->nPerProc=nodePerProcess;
        
        
        DG->nEdge=G.verPtr[start+nodePerProcess]-G.verPtr[start];
        DG->startNode=start;
        DG->endNode=start+nodePerProcess-1;
        
        
        //Copy vertex Pointers
        G.verPtr=(long long*)_mm_malloc((G.nVer+1)*sizeof(long long),64);
        inf.read((char*)&G.verPtr[0],sizeof(long long)*(G.nVer+1));
        DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
        
        #pragma omp parallel for
        for(long long i=start;i<start+nodePerProcess;i++)
            DG->verPtr[i-start]=G.verPtr[i]-offset;
        DG->verPtr[DG->nVer]=DG->nEdge;
        _mm_free(G.verPtr);
        
        //Copy Edge Indices and Edge Weights
        G.verInd=(long long*)_mm_malloc(G.nEdge*sizeof(long long),64);
        inf.read((char*)&G.verInd[0],sizeof(long long)*G.nEdge);
        DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
        
        #pragma omp parallel for
        for(long long i=offset;i<offset+DG->nEdge;i++)
            DG->verInd[i-offset].id=G.verInd[i];
        
        _mm_free(G.verInd);
        
        G.verWt=(float*)_mm_malloc(G.nEdge*sizeof(float),64);
        inf.read((char*)&G.verWt[0],sizeof(float)*G.nEdge);
        
        #pragma omp parallel for
        for(long long i=offset;i<offset+DG->nEdge;i++)
            DG->verInd[i-offset].weight=G.verWt[i];
        
        _mm_free(G.verWt);
        
     		/// recieve the b values from the master..
     	DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        MPI_Recv(&DG->bVer[0],DG->nVer,MPI_LONG_LONG,0,1,comm, &stat);
     }
    
    inf.close(); 
    
    return 1;

}*/

bool UdistGraphReading(DCSR* DG, char* pf, char* bf, int b, int s, unsigned long np, MPI_Comm comm)
{
    int rank;
    MPI_Status stat;
    MPI_Comm_rank(comm, &rank);	
    
    TCSR G;
    G.readCSRbin(pf);
    
    long long start,offset,count;
    long long nodePerProcess=ceil(G.nVer/(np*1.0));;
    
    if(rank==0) // Extra adjustment for the master node because it will have the excess nodes
    {
    	DG->gnVer=G.nVer;
        DG->gnEdge=G.nEdge;
        DG->nVer=G.nVer-(nodePerProcess*(np-1));
        DG->nEdge=G.verPtr[DG->nVer];
        DG->nProc=np;
        DG->rank=rank;
        DG->startNode=0;
        DG->endNode=G.nVer-(nodePerProcess*(np-1))-1;
        DG->nPerProc=nodePerProcess;
        
        //Copy vertex Pointers
        DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
        
        #pragma omp parallel for
        for(long long i=0;i<=DG->nVer;i++)
            DG->verPtr[i]=G.verPtr[i];
        _mm_free(G.verPtr);
        
        //Copy Edge Indices and Edge Weights
        DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
        
        #pragma omp parallel for
        for(long long i=0;i<DG->nEdge;i++)
        {
            DG->verInd[i].id=G.verInd[i];
            DG->verInd[i].weight=(float)G.verWt[i];
        }
        _mm_free(G.verInd);
        _mm_free(G.verWt);
        
        //Copy bV value
        DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        
        if(b>0)
        {    
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
            {    
                long long deg=G.verPtr[i+1]-G.verPtr[i];
                if(deg>b)
                    DG->bVer[i]=b;
                else
                    DG->bVer[i]=deg;
                if(deg==0)
                    cout<<"Degree 0 node: "<<endl;
            }
        }
        else
        {
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
            {    
                long long deg=G.verPtr[i+1]-G.verPtr[i];         
                if(deg<=2)
                    DG->bVer[i]=1;
                else
                    DG->bVer[i]=(long long)(deg/(log2(deg)*1.0));
            }
        }
        
        //Copy sV value
        DG->sVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        
        if(s>0)
        {    
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
                DG->sVer[i]=s;
        }
        else
        {
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
            {    
                if(DG->bVer[i]>4)
                    DG->sVer[i]=(long long)(DG->bVer[i]*3/4.0);
                else DG->sVer[i]=1;
            }
        }
    }
    else   // for other nodes
    {
        start=G.nVer-(nodePerProcess*(np-1));
        start=start+(rank-1)*nodePerProcess;
        offset=G.verPtr[start];
    		
        DG->gnVer=G.nVer;
        DG->gnEdge=G.nEdge;
        DG->nVer=nodePerProcess;
        DG->nProc=np;
        DG->rank=rank;
        DG->nPerProc=nodePerProcess;
        
        
        DG->nEdge=G.verPtr[start+nodePerProcess]-G.verPtr[start];
        DG->startNode=start;
        DG->endNode=start+nodePerProcess-1;
        
        
        //Copy vertex Pointers
        DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
        
        #pragma omp parallel for
        for(long long i=start;i<start+nodePerProcess;i++)
            DG->verPtr[i-start]=G.verPtr[i]-offset;
        DG->verPtr[DG->nVer]=DG->nEdge;
        _mm_free(G.verPtr);
        
        //Copy Edge Indices and Edge Weights
        DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
        
        #pragma omp parallel for
        for(long long i=offset;i<offset+DG->nEdge;i++)
        {    
            DG->verInd[i-offset].id=G.verInd[i];
            DG->verInd[i-offset].weight=G.verWt[i];
				}
        _mm_free(G.verInd);
        _mm_free(G.verWt);
        
     		/// recieve the b values from the master..
     	DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        if(b>0)
        {    
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
            {    
                long long deg=G.verPtr[i+1]-G.verPtr[i];
                if(deg>b)
                    DG->bVer[i]=b;
                else
                    DG->bVer[i]=deg;
                if(deg==0)
                    cout<<"Degree 0 node: "<<endl;
            }
        }
        else
        {
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
            {    
                long long deg=G.verPtr[i+1]-G.verPtr[i];         
                if(deg<=2)
                    DG->bVer[i]=1;
                else
                    DG->bVer[i]=(long long)(deg/(log2(deg)*1.0));
            }
        }
        
        //Copy sV value
        DG->sVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        
        if(s>0)
        {    
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
                DG->sVer[i]=s;
        }
        else
        {
            #pragma omp parallel for
            for(long long i=0;i<DG->nVer;i++)
            {    
                if(DG->bVer[i]>4)
                    DG->sVer[i]=(long long)(DG->bVer[i]*3/4.0);
                else DG->sVer[i]=1;
            }
        }
     }
    
    
    
    return 1;

}
bool distNodePartition( DCSR* DG, char* pf, char* bf, unsigned long np, MPI_Comm comm)
{

    int rank;
    long long metaData[8];
    MPI_Status stat;
    MPI_Comm_rank(comm, &rank);

    if(rank==0)
    {
        long long nodePerProcess;
        long long start,offset;
        
        /// Read the input graph
        TCSR G;
        G.readCSRbin(pf);
        cout<<"(Process 0) Graph Reading done: "<<G.nVer<<" "<<G.nEdge<<endl;
        
        long long *bV=(long long*)_mm_malloc(G.nVer*sizeof(long long),64);
        if(bf==NULL)
        {
            #pragma omp parallel for
            for(long long i=0;i<G.nVer;i++)
            {
                //bV[i]=5;
                
                long long deg=(long long)sqrt(G.verPtr[i+1]-G.verPtr[i]);         
                if(deg<=1)
                    bV[i]=1;
                else
                    bV[i]=rand()%deg+1;
            }
        }
        
        // Calculating nodes per process
        //cout<<"B calculation done"<<endl; 
        nodePerProcess=ceil(G.nVer/(np*1.0));
        start=G.nVer-(nodePerProcess*(np-1)); // Master will be excess
        metaData[0]=G.nVer;
        metaData[1]=G.nEdge;
        metaData[2]=np;
        metaData[3]=nodePerProcess;
        
        // Now send chunks of the graph to different processors
        for(int i=1;i<np;i++)
        {
            offset=G.verPtr[start];
            //Calculate how many edges
            metaData[4]=G.verPtr[start+nodePerProcess]-G.verPtr[start];
            metaData[5]=offset; // offset
            metaData[6]=start;
            metaData[7]=start+nodePerProcess-1;
            
            //cout<<"Sending to process: "<<i<<endl;
            //cout<<"Send metaData: 64"<<endl;
            MPI_Send(&metaData[0],8,MPI_LONG_LONG,i,1,comm);
            
            //cout<<"Send Vertex Pointer: "<<nodePerProcess*8<<endl;
            MPI_Send(&G.verPtr[start],nodePerProcess,MPI_LONG_LONG,i,2,comm);

            //cout<<"Send Edge indices: "<<metaData[4]*4<<endl;
            MPI_Send(&G.verInd[offset],metaData[4],MPI_LONG_LONG,i,3,comm);

            //cout<<"Send Edge Weights: "<<metaData[4]*4<<endl;
            MPI_Send(&G.verWt[offset],metaData[4],MPI_FLOAT,i,4,comm);
            
            //cout<<"Send b values: "<<nodePerProcess*4<<endl;
            MPI_Send(&bV[start],nodePerProcess,MPI_LONG_LONG,i,5,comm);
            
            start=start+nodePerProcess; // adjusting the start
        }
        // Now adjust the MASTER's graph

        DG->gnVer=G.nVer;
        DG->gnEdge=G.nEdge;
        DG->nVer=G.nVer-(nodePerProcess*(np-1));
        DG->nEdge=G.verPtr[DG->nVer];
        DG->nProc=np;
        DG->rank=rank;
        DG->startNode=0;
        DG->endNode=G.nVer-(nodePerProcess*(np-1))-1;
        DG->nPerProc=nodePerProcess;
        
        //Copy bV value
        DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        
        #pragma omp parallel for
        for(long long i=0;i<DG->nVer;i++)
            DG->bVer[i]=bV[i];
        _mm_free(bV);

        //Copy vertex Pointers
        DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
        
        #pragma omp parallel for
        for(long long i=0;i<=DG->nVer;i++)
            DG->verPtr[i]=G.verPtr[i];
        _mm_free(G.verPtr);
        
        //Copy Edge Indices and Edge Weights
        DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
        
        #pragma omp parallel for
        for(long long i=0;i<DG->nEdge;i++)
        {
            DG->verInd[i].id=G.verInd[i];
            DG->verInd[i].weight=(float)G.verWt[i];
        }
        
        _mm_free(G.verInd);
        _mm_free(G.verWt);
        
        //cout<<"Local graph in process 0 done"<<endl;
        return 1;
    }
    else
    {
        MPI_Recv(&metaData[0],8,MPI_LONG_LONG,0,1,comm, &stat);
        
        long long offset;
        DG->gnVer=metaData[0];
        DG->gnEdge=metaData[1];
        DG->nVer=metaData[3];
        DG->nEdge=metaData[4];
        DG->nProc=metaData[2];
        DG->rank=rank;
        DG->startNode=metaData[6];
        DG->endNode=metaData[7];
        DG->nPerProc=metaData[3];
        offset=metaData[5];

        //Copy vertex Pointers
        DG->verPtr=(long long*)_mm_malloc((DG->nVer+1)*sizeof(long long),64);
        MPI_Recv(&DG->verPtr[0],DG->nVer,MPI_LONG_LONG,0,2,comm, &stat);
        
        //Copy Edge Indices and Edge Weights
        DG->verInd=(Edge*)_mm_malloc(DG->nEdge*sizeof(Edge),64);
        
        long long* temp1=(long long*)_mm_malloc(DG->nEdge*sizeof(long long),64);
        MPI_Recv(&temp1[0],DG->nEdge,MPI_LONG_LONG,0,3,comm, &stat);

        #pragma omp parallel for
        for(long long i=0;i<DG->nEdge;i++)
            DG->verInd[i].id=temp1[i];
        _mm_free(temp1);
        
        
        float* temp2=(float*)_mm_malloc(DG->nEdge*sizeof(float),64);
        MPI_Recv(&temp2[0],DG->nEdge,MPI_FLOAT,0,4,comm, &stat);
        
        #pragma omp parallel for
        for(long long i=0;i<DG->nEdge;i++)
            DG->verInd[i].weight=temp2[i];
        _mm_free(temp2);

        //Copy bV value
        DG->bVer=(long long*)_mm_malloc(DG->nVer*sizeof(long long),64);
        MPI_Recv(&DG->bVer[0],DG->nVer,MPI_LONG_LONG,0,5,comm, &stat);
        
        //Now Adjust the vertex pointers by offset
        #pragma omp parallel for
        for(long long i=0;i<DG->nVer;i++)
            DG->verPtr[i]-=offset;
        DG->verPtr[DG->nVer]=DG->nEdge;

        return 1;

    }

}

__forceinline bool heapComp(Info left, Info right)
{
    return (left.weight<right.weight || (left.weight==right.weight && left.id<right.id));
}


void Node::AddHeap(float wt, long long idx )
{
    if(curSize==maxSize)
    {
        if(maxSize>2)
        {
            //heap[0].weight=wt;
            //heap[0].id=idx;

            /// Only heapify one branch of the heap tree
            long long small,ri,li,pi=0;
            long long done=0;
            
            if(heap[2].weight >heap[1].weight || (heap[2].weight==heap[1].weight && heap[2].id>heap[1].id))
                small=1;
            else
                small=2;
                
            if(wt>heap[small].weight || (wt==heap[small].weight && idx>heap[small].id))
            {
                heap[0].weight=heap[small].weight;
                heap[0].id=heap[small].id;
                heap[small].weight=wt;
                heap[small].id=idx;
            }   
            else
            {
                heap[0].weight=wt;
                heap[0].id=idx;
            }

            pi=small;
            while(!done)
            {
                li=2*pi+1;
                ri=2*pi+2;
                small=pi;

                if(li <maxSize && (heap[li].weight< heap[small].weight || (heap[li].weight == heap[small].weight && heap[li].id < heap[small].id )))
                    small=li;
                if(ri <maxSize && (heap[ri].weight< heap[small].weight || (heap[ri].weight == heap[small].weight && heap[ri].id < heap[small].id)))
                    small=ri;

                if(small != pi)
                {
                    wt=heap[pi].weight;
                    idx=heap[pi].id;

                    heap[pi].weight=heap[small].weight;
                    heap[pi].id=heap[small].id;

                    heap[small].weight=wt;
                    heap[small].id=idx;
                }
                else done=1;

                pi=small;
            }
        }
        else
        {
            if(maxSize != 1 && (wt>heap[1].weight || (wt==heap[1].weight && idx > heap[1].id)))
            {
                heap[0].weight=heap[1].weight;
                heap[0].id=heap[1].id;
                heap[1].weight=wt;
                heap[1].id=idx;
            }
            else
            {
                heap[0].weight=wt;
                heap[0].id=idx;
            }
        }

        minEntry.id=heap[0].id;
        minEntry.weight=heap[0].weight;
    }
    else
    {
        heap[curSize].weight=wt;
        heap[curSize].id=idx;
        curSize++;
        if(curSize==maxSize)
        {    
            sort(heap,heap+curSize,heapComp);
            minEntry.weight=heap[0].weight;
            minEntry.id=heap[0].id;
        }
    }            
}

void Node::Add(float wt, long long idx )
{
    if(curSize==maxSize)
    {
        if(maxSize>2)
        {
            
            //heap[0].weight=wt;
            //heap[0].id=idx;

            long long small,ri,li,pi=0;
            long long done=0;
            
            if(heap[2].weight >heap[1].weight || (heap[2].weight==heap[1].weight && heap[2].id>heap[1].id))
                small=1;
            else
                small=2;
                
            if(wt>heap[small].weight || (wt==heap[small].weight && idx>heap[small].id))
            {
                heap[0].weight=heap[small].weight;
                heap[0].id=heap[small].id;
                heap[small].weight=wt;
                heap[small].id=idx;
            }   
            else
            {
                heap[0].weight=wt;
                heap[0].id=idx;
            }

            pi=small;    
            while(!done)
            {
                li=2*pi+1;
                ri=2*pi+2;
                small=pi;

                if(li <maxSize && (heap[li].weight< heap[small].weight || (heap[li].weight == heap[small].weight && heap[li].id < heap[small].id )))
                    small=li;
                if(ri <maxSize && (heap[ri].weight< heap[small].weight || (heap[ri].weight == heap[small].weight && heap[ri].id < heap[small].id)))
                    small=ri;

                if(small != pi)
                {
                    wt=heap[pi].weight;
                    idx=heap[pi].id;

                    heap[pi].weight=heap[small].weight;
                    heap[pi].id=heap[small].id;

                    heap[small].weight=wt;
                    heap[small].id=idx;
                }
                else done=1;

                pi=small;
            }
        }
        else
        {
            if(maxSize != 1 &&(wt>heap[1].weight || (wt==heap[1].weight && idx > heap[1].id)))
            {
                heap[0].weight=heap[1].weight;
                heap[0].id=heap[1].id;
                heap[1].weight=wt;
                heap[1].id=idx;
            }
            else
            {
                heap[0].weight=wt;
                heap[0].id=idx;
            }

        }
        minEntry.id=heap[0].id;
        minEntry.weight=heap[0].weight;
    }
    else
    {
        switch(curSize)
        {
            case 0:
                heap[0].weight=wt;
                heap[0].id=idx;
                break;
            case 1:
                if(heap[0].weight< wt || (heap[0].weight == wt && heap[0].id < idx))
                {    
                    heap[1].weight=wt;
                    heap[1].id=idx;
                }
                else
                {
                    heap[1].weight=heap[0].weight;
                    heap[1].id=heap[0].id;
                    
                    heap[0].weight=wt;
                    heap[0].id=idx;
                }
                break; 
            case 2:
                if(heap[0].weight< wt || (heap[0].weight == wt && heap[0].id < idx))
                {    
                    heap[2].weight=wt;
                    heap[2].id=idx;
                }
                else
                {
                    heap[2].weight=heap[0].weight;
                    heap[2].id=heap[0].id;
                    
                    heap[0].weight=wt;
                    heap[0].id=idx;
                }
                break;
            default:
                heap[curSize].weight=wt;
                heap[curSize].id=idx;
                
                int pi,ci=curSize;
                int done=0;
                
                while(!done)
                {
                    pi=(int)floor((ci-1)/2.0);

                    if(heap[pi].weight< heap[ci].weight || (heap[pi].weight == heap[ci].weight && heap[pi].id < heap[ci].id ))
                        done=1;
                    else
                    {
                        wt=heap[pi].weight;
                        idx=heap[pi].id;

                        heap[pi].weight=heap[ci].weight;
                        heap[pi].id=heap[ci].id;

                        heap[ci].weight=wt;
                        heap[ci].id=idx;
                    }

                    if(pi==0)
                        break;

                    ci=pi;
                }
                break;
        
        }// switch
        curSize++;
        if(curSize==maxSize)
        {
            minEntry.weight=heap[0].weight;
            minEntry.id=heap[0].id;
        }
    }

}


bool verifyMatching(MCSR* M)
{
    bool flag=true;
    float weight=0.0;
    //#pragma omp parallel for schedule(static)
    for(long long i=0;i<M->nVer;i++)
    {
        for(long long j=M->verPtr[i];j<M->verPtr[i+1];j++)
        {
            long long a=M->verInd[j];
            weight+=M->verWt[j];
            
            flag=false;
            for(long long k=M->verPtr[a];k<M->verPtr[a+1];k++)
            {    
                if(M->verInd[k]==i)
                {
                    flag=true;
                    break;
                }
            }
            if(flag==false)
            { 
                /*cout<<"("<<i<<","<<a<<") :";
                for(int k=M->verPtr[i];k<M->verPtr[i+1];k++)
                    cout<<M->verInd[k]<<"("<<M->verWt[k]<<")"<<" ";
                cout<<" I ";
                for(int k=M->verPtr[a];k<M->verPtr[a+1];k++)
                    cout<<M->verInd[k]<<"("<<M->verWt[k]<<")"<<" ";
                cout<<endl;*/
                
                break;
            }
        }
        if(flag==false)
            break;
    }
    
    if(flag==false)
        return false;
    else
    {
        cout<<"Matching Weight: "<<weight/2.0<<endl;
        return true;
    }
}


__forceinline bool comparator(Edge left, Edge right)
{
    return (left.weight > right.weight || (left.weight==right.weight && left.id > right.id));
}


__forceinline bool comparatorE(EdgeE left, EdgeE right)
{
    return (left.weight > right.weight || (left.weight==right.weight && left.id > right.id));
}


/*int custom_sort_optimized(Edge* verInd, int start, int end, int step, int* order, int type, Edge* neighbors)
{
    int part=start+step;
    int tstart, tend,tpart,k,length;
    int id,p,r,tid;
    double weight;
    __declspec(aligned(64)) Edge temp;
    __declspec(aligned(64)) Edge median;

    switch(type)
    {
        case 1: break;
        case 2: part=end;
                sort(verInd+start,verInd+end,comparator);
                //csort(verInd,start,end);
                break;
        
        case 3: if(part>=end)
                {
                    part=end;
                    sort(verInd+start,verInd+end,comparator);
                }
                else
                {
                    int last=(end-start)/step;
                    //if(last>50)
                        //last=50;
                    //multiQselectIter(verInd,start,start,end-1,order,0,last-1,st);
                    multiQselect(verInd,start,start,end-1,order,0,last-1);
                    sort(verInd+start,verInd+part,comparator);
                }
                break;
        case 4: if(part>=end)
                {
                    part=end;
                    sort(verInd+start,verInd+end,comparator);
                    //my_small_sort(verInd+start, (end  - start));
                }
                else
                {   
                    tend=end-1;
                    tstart=start;
                    k=step+1;

                    while(true)
                    {
                        p=tstart;
                        r=tend;
                        weight = verInd[(r+p)/2].weight;
                        id=verInd[(r+p)/2].id;
			median = verInd[(r+p)/2];

#if defined _ACTIVATE_MIC_CODE_ && defined __MIC__
			int num = (tend - tstart + 1);
			int num_aligned = num/16 * 16;
			SIMDFPTYPE v_weight = _MM_SET(weight);
			SIMDINTTYPE v_id = _MM_SET_INT(id);
			Edge * write_1 = verInd + tstart;
			Edge * write_2 = neighbors;
			int cnt_write_1 = 0;
			int cnt_write_2 = 0;

			for(int i = tstart; i < tstart + num_aligned; i+=16)
			{
				// AOS, hence two loads required to get 16 elements
				SIMDINTTYPE v_i = _MM_LOADU_INT((int *)(verInd + i));	
				SIMDINTTYPE v_i_16 = _MM_LOADU_INT((int *)(verInd + i + 8));

				// First element in structure is id, and second is weight.
				// Mask with 0xAAAA to get weight, and 0x5555 to get id
				SIMDMASKTYPE v_gt_weight_1 = _MM_CMP_LT_MASK(0xAAAA, v_weight, _mm512_castsi512_ps(v_i));	
				SIMDMASKTYPE v_eq_weight_1 = _MM_CMP_EQ_MASK(0xAAAA, _mm512_castsi512_ps(v_i), v_weight);
				SIMDMASKTYPE v_gt_id_1     = _MM_CMP_LT_MASK_INT(0x5555, v_id, v_i);
				SIMDMASKTYPE v_mask_left_1 = _mm512_kor(v_gt_weight_1, _mm512_kand(v_eq_weight_1, (v_gt_id_1<<1)));
				unsigned int cnt_1 = _mm_countbits_32(v_mask_left_1);
				v_mask_left_1 = ((v_mask_left_1 >> 1)) | v_mask_left_1;
				_MM_STOREU_MASK_INT((int *)(write_1), v_mask_left_1, v_i);	
				write_1 += cnt_1; cnt_write_1 += cnt_1;

				SIMDMASKTYPE v_lt_weight_1 = _MM_CMP_LT_MASK(0xAAAA, _mm512_castsi512_ps(v_i), v_weight);	
				SIMDMASKTYPE v_lt_id_1     = _MM_CMP_LT_MASK_INT(0x5555, v_i, v_id);
				SIMDMASKTYPE v_mask_right_1 = _mm512_kor(v_lt_weight_1, _mm512_kand(v_eq_weight_1, (v_lt_id_1<<1)));
				unsigned int cnt_right_1 = _mm_countbits_32(v_mask_right_1);
				v_mask_right_1 = ((v_mask_right_1 >> 1)) | v_mask_right_1;
				_MM_STOREU_MASK_INT((int *)(write_2), v_mask_right_1, v_i);	
				write_2 += cnt_right_1; cnt_write_2 += cnt_right_1;


				SIMDMASKTYPE v_gt_weight_2 = _MM_CMP_LT_MASK(0xAAAA, v_weight, _mm512_castsi512_ps(v_i_16));	
				SIMDMASKTYPE v_eq_weight_2 = _MM_CMP_EQ_MASK(0xAAAA, _mm512_castsi512_ps(v_i_16), v_weight);
				SIMDMASKTYPE v_gt_id_2     = _MM_CMP_LT_MASK_INT(0x5555, v_id, v_i_16);
				SIMDMASKTYPE v_mask_left_2 = _mm512_kor(v_gt_weight_2, _mm512_kand(v_eq_weight_2, (v_gt_id_2<<1)));
				unsigned int cnt_2 = _mm_countbits_32(v_mask_left_2);
				v_mask_left_2 = ((v_mask_left_2 >> 1)) | v_mask_left_2;
				_MM_STOREU_MASK_INT((int *)(write_1), v_mask_left_2, v_i_16);	
				write_1 += cnt_2; cnt_write_1 += cnt_2;

				SIMDMASKTYPE v_lt_weight_2 = _MM_CMP_LT_MASK(0xAAAA, _mm512_castsi512_ps(v_i_16), v_weight);	
				SIMDMASKTYPE v_lt_id_2     = _MM_CMP_LT_MASK_INT(0x5555, v_i_16, v_id);
				SIMDMASKTYPE v_mask_right_2 = _mm512_kor(v_lt_weight_2, _mm512_kand(v_eq_weight_2, (v_lt_id_2<<1)));
				unsigned int cnt_right_2 = _mm_countbits_32(v_mask_right_2);
				v_mask_right_2 = ((v_mask_right_2 >> 1)) | v_mask_right_2;
				_MM_STOREU_MASK_INT((int *)(write_2), v_mask_right_2, v_i_16);	
				write_2 += cnt_right_2; cnt_write_2 += cnt_right_2;
			}

			for(int i = tstart + num_aligned; i <= tend; i++)
			{
				if( verInd[i].weight > weight || (verInd[i].weight==weight && verInd[i].id>id))
				{
					*write_1 = verInd[i];
					write_1++; cnt_write_1++;
				}
				else if(verInd[i].weight < weight || (verInd[i].weight==weight && verInd[i].id<id))
				{
					*write_2 = verInd[i];
					write_2++; cnt_write_2++;
				}	
			}

			// add the median at the end of write_1
			*write_1 = median;
                        write_1++; cnt_write_1++;
			
 			// copy back
			int cnt_write_2_aligned = cnt_write_2/8 * 8;

			for(int i = 0; i < cnt_write_2_aligned; i+=8)
			{
				_MM_STOREU_INT((int *)(write_1), _MM_LOAD_INT((int *)(neighbors + i))); write_1 += 8;
			}
			for(int i = cnt_write_2_aligned; i < cnt_write_2; i++)
			{
				*write_1 = neighbors[i];
				write_1++;
			}
			
			r = tstart + cnt_write_1 - 1;	
#else
                        while ( p < r )
                        {
                            while ( verInd[p].weight > weight || (verInd[p].weight==weight && verInd[p].id>id))
                                p++;
                            while ( verInd[r].weight < weight || (verInd[r].weight==weight && verInd[r].id < id) )
                                r--;
                            
                            if(verInd[p].id==verInd[r].id)
                                p++;
                            else
                                if( p < r ) 
                                {
				    *(long long int *)(&temp) = *(long long int *)(verInd + p);
				    *(long long int *)(verInd + p) = *(long long int *)(verInd + r);
				    *(long long int *)(verInd + r) = *(long long int *)(&temp);
                                }
                        }
#endif
                        length=r-start+1;
                        if(length==k)
                            break;
                        else
                        {
                            if(length > k)
                                tend=r-1;
                            else
                                tstart=r+1;
                        }
                        if(tstart==tend)
                            break;

                    }

                    //nth_element(verInd+start,verInd+part,verInd+end,comparator);
                    sort(verInd+start,verInd+part,comparator);
                    //my_small_sort(verInd+start,(part - start));
                }
                break;

        default: sort(verInd+start,verInd+end,comparator);
    }
    return part;
}*/

long long  custom_sort(Edge* verInd, long long start, long long end, long long step)
{
    long long part=start+step;
    long long tstart, tend,tpart,k,length;
    long long id,p,r,tid;
    double weight;
    Edge temp;
    if(part>=end)
    {
        part=end;
        sort(verInd+start,verInd+end,comparator);
    }
    else
    {   
        tend=end-1;
        tstart=start;
        k=step+1;
        while(true)
        {
            p=tstart;
            r=tend;
            weight = verInd[(r+p)/2].weight;
            id=verInd[(r+p)/2].id;
            while ( p < r )
            {
                while ( verInd[p].weight > weight || (verInd[p].weight==weight && verInd[p].id>id))
                    p++;
                while ( verInd[r].weight < weight || (verInd[r].weight==weight && verInd[r].id < id) )
                    r--;
                
                if(verInd[p].id==verInd[r].id)
                    p++;
                else
                    if( p < r ) 
                    {
                        temp.id= verInd[p].id;
                        temp.weight=verInd[p].weight;

                        verInd[p].id  = verInd[r].id;
                        verInd[p].weight = verInd[r].weight;

                        verInd[r].id = temp.id;
                        verInd[r].weight = temp.weight;
                    }
            }

            length=r-start+1;
            if(length==k)
                break;
            else
            {
                if(length > k)
                    tend=r-1;
                else
                    tstart=r+1;
            }
            if(tstart==tend)
                break;
        }

        sort(verInd+start,verInd+part,comparator);
    }
    return part;
}

bmatching_parameters::bmatching_parameters()
    :problemname(NULL),bFileName(NULL),b(10),algorithm(8),step(3),sstep(1),nsort(false),verbose(false),hybrid(true),nstep(1)
{}

void bmatching_parameters::usage()
{
    const char *params =
	"\n\n"
    "Usage: %s -f <problemname> -g <bfilename> -b <bval> -t <type> -p <sstep> -n <nstep> -q -v -h -m\n\n"
	"	-f problemname  : file containing graph. Currently inputs .cbin files\n"
	"	-g bfilename    : Optional input. (currently not implemented)Only use when the b values for differnt vertices are different\n"
	"	-b bval         : b value for all vertices.\n"
	"	-t type         : Which algorithm to use\n"
    "                           1= Greedy Serial  \n"
    "                           2= LD Serial  \n"
    "                           3= Eager Unsorted  \n"
    "                           4= Eager Sorted   \n"
    "                           5= Eager Partial  \n"
    "                           6= Delayed Unsroted  \n"
    "                           7= Delayed Sorted  \n"
    "                           8= Delayed Partial  \n"
    "                           9= Path Growing with DP  \n\n"
    "   -s step         : step size for partial sorting \n\n"
    "   -m              : All MPI mode (no hybrid) \n\n"
    "   -p sstep             : b(v) step \n\n"
    "   -q nsort             : node sorting \n\n";
    "   -n nstep             : node step \n\n";

    fprintf(stderr, params);
}

bool bmatching_parameters::parse(int argc, char** argv)
{
    static struct option long_options[]=
    {
        // These options don't take extra arguments
        {"verbose", no_argument, NULL, 'v'},
        {"nsort", no_argument, NULL, 'q'},
        {"help", no_argument, NULL, 'h'},
        {"nohybrid", no_argument, NULL, 'm'},
        
        // These do
        {"problem", required_argument, NULL, 'f'},
        {"bVar", required_argument, NULL, 'g'},
        {"b", required_argument, NULL, 'b'},
        {"type", required_argument, NULL, 't'},
        {"step", required_argument, NULL, 's'},
        {"sstep", required_argument, NULL, 'p'},
        {"nstep", required_argument, NULL, 'n'},
        {NULL, no_argument, NULL, 0}
    };

    static const char *opt_string="vhmqf:g:b:t:s:p:n:";
    int opt, longindex;
    opt=getopt_long(argc,argv,opt_string,long_options,&longindex);
    while(opt != -1)
    {
        switch(opt)
        {
            case 'v': verbose=true; 
                      break;
            
            case 'q': nsort=true; 
                      break;

            case 'h': usage(); 
                      return false; 
                      break;

            case 'm': hybrid=false; 
                      break;

            case 'f': problemname=optarg; 
                      if(problemname==NULL)
                      {
                        cerr<<"Problem file is not speficied"<<endl;
                        return false;  
                      }
                      break;

            case 'g': bFileName=optarg;
                      if(bFileName==NULL)
                      {
                        cerr<<"Problem file is not speficied"<<endl;
                        return false;  
                      }
                      break;
            case 'b': b=atoi(optarg);
                      if(b==0)
                      {
                        cerr<<"the b value can't be zero"<<endl;
                        return false;
                      }
                      break;
            case 't': algorithm=atoi(optarg);
                      if(algorithm < 1 || algorithm > 9)
                      {
                        cerr<<"The algorithm type should be between 1 and 8, please type -h to see the details"<<endl;
                        return false;
                      }
                      break;

            case 's': step=atoi(optarg);
                      if(step==0)
                      {
                        cerr<<"the step value can't be zero"<<endl;
                        return false;
                      }
                      break;
            case 'p': sstep=atoi(optarg);
                      if(sstep<0)
                      {
                        cerr<<"the super step value can't be negative"<<endl;
                        return false;
                      }
                      break;
            case 'n': nstep=atoi(optarg);
                      if(sstep<=0)
                      {
                        cerr<<"the super step value has to be positive"<<endl;
                        return false;
                      }
                      break;
        }
        opt=getopt_long(argc,argv,opt_string,long_options,&longindex);
    }

    return true;
}
int main(int argc, char** argv)
{
    /*if(argc<5)
    {
        cout<<"Not enough inputs. ./bMatching <input.cbin> <b> <sort_type> <eager/delayed>"<<endl;
        cout<<"<sort type>: unsorted=1, sorted=2, partial sorted=3"<<endl;
        cout<<"<eager/delayed>: eager=1, delayed=2"<<endl;
        exit(1);
    }*/
    
    bmatching_parameters opts;
    if(!opts.parse(argc,argv))
    {
        cout<<"Argument Parsing Done..!!"<<endl;
        return -1;
    }
    /*********MPI INIT ****/
    int rank, len, rc, numProc; 
    char hostname[MPI_MAX_PROCESSOR_NAME];

     rc = MPI_Init(&argc,&argv);
     if (rc != MPI_SUCCESS) 
     {
        printf ("Error starting MPI program. Terminating.\n");
        MPI_Abort(MPI_COMM_WORLD, rc);
     }

     MPI_Comm_size(MPI_COMM_WORLD,&numProc);
     MPI_Comm_rank(MPI_COMM_WORLD,&rank);
     MPI_Get_processor_name(hostname, &len);
     //printf ("Number of tasks= %d My rank= %d Running on %s\n", numProc,rank,hostname);
    /********Data distribute ********/

    double t1;
    
    if(rank==0)
    	t1=omp_get_wtime();
    
    DCSR G;
    //distNodePartition(&G, opts.problemname, opts.bFileName,numProc, MPI_COMM_WORLD); 
    distGraphReading(&G, opts.problemname, opts.bFileName,opts.b, opts.sstep,numProc, MPI_COMM_WORLD);
    //MPI_Barrier(MPI_COMM_WORLD);
    if(rank==0)
    {
        t1=omp_get_wtime()-t1;
        cout<<"Data distribution done :"<<t1<<" sec"<<endl;
        cout<<"Vertices: "<<G.gnVer<<" Edges: "<<G.gnEdge/2<<endl;
        #pragma omp parallel
        {
            #pragma omp master
            cout<<"Number of Nodes: "<<numProc<<
            " each with: "<<omp_get_num_threads()<<endl;
        }
    }
    long long numThreads;

    /************************************/
    //Edge sroting tom find a pivot
    /*EdgeE* verIndCopy=new EdgeE[G.nEdge];
    #pragma omp parallel for
    for(int i=0;i<G.nVer;i++)
    {
        for(int j=G.verPtr[i];j<G.verPtr[i+1];j++)
        {    
            verIndCopy[j].head=i; 
            verIndCopy[j].id=G.verInd[j].id;
            verIndCopy[j].weight=G.verInd[j].weight;
        }
    }

    //for(int i=0;i<10;i++)
        //cout<<verIndCopy[i].weight<<" ";
    //cout<<endl;
    sort(verIndCopy,verIndCopy+G.nEdge,comparatorE);
    int index;
    for(index=0;index<G.nEdge;index++)
        if(verIndCopy[index].weight<=0)
            break;
    //for(int i=0;i<10;i++)
        //cout<<verIndCopy[i].weight<<" ";
    //cout<<endl;*/
    /***********************************/
    
    double rt_end = omp_get_wtime();	
    //cout<<"(Process "<<G.rank<<") Graph: "<<G.nVer<<" "<<G.nEdge<<endl;

    
    int type=opts.algorithm;
    long long stepM=opts.step;
    long long npart=opts.nstep;

    long long *b=&G.bVer[0];
    long long *sVer=&G.sVer[0];

    int* nlocks=(int*)_mm_malloc(G.nVer*sizeof(int),64);       
    long long* start=(long long*)_mm_malloc(G.nVer*sizeof(long long),64); 
    long long* end=(long long*)_mm_malloc(G.nVer*sizeof(long long),64);  
    Node* S=(Node*)_mm_malloc(G.gnVer*sizeof(Node),64);      
    
    #pragma omp parallel
    numThreads=omp_get_num_threads();
    
    numThreads=numThreads/2; // One thread perprocess, assuming hyperthreading

    if(opts.hybrid)
        omp_set_num_threads(numThreads);
    else
        omp_set_num_threads(1);
    
    #pragma omp parallel for
    for(long long i=0;i<G.gnVer;i++)       
    {    
        if(i>=G.startNode && i<=G.endNode)
            S[i].heap=(Info*)_mm_malloc(b[i-G.startNode]*sizeof(Info),64); 
        else
            S[i].heap=(Info*)_mm_malloc(sizeof(Info),64);
    }
    //cout << "Memory allocation took " << omp_get_wtime() - rt_end << endl;	

    t1=omp_get_wtime();

    switch(type)
    {
        case 1: // Greedy Serial
                /*Node* S1=(Node*)_mm_malloc(G.nVer*sizeof(Node),64);      //Heap data structure
                for(int i=0;i<G.nVer;i++)       
                    S1[i].heap=(Info*)_mm_malloc(b[i]*sizeof(Info),64);      //Each heap of size b
                
                float* M=(float*)_mm_malloc(2*sizeof(float),64);

		double gr_time_1 = omp_get_wtime();
                for(int i=0;i<G.nVer;i++)
                    start[i]=b[i];
                int best=greedySerial(&G,S,S1,start,M,mark,end);

		cout<<"Total Time: "<< omp_get_wtime() - gr_time_1 <<endl;
                if(best==1)
                    S=S1;*/       
                break;
        
        case 2: // LD Serial
                //for(int i=0;i<G.nVer;i++)
                //start[i]=b[i];

                //localDomSerial(&G,S,start,end);
                break;
        
        case 3: //bSuitorBPQ(&G,b[0],nlocks,S,start,end,mark,order,1,stepM,St,opts.verbose);
                break;

        case 4: //bSuitorBPQ(&G,b[0],nlocks,S,start,end,mark,order,2,stepM,St,opts.verbose);
                break;

        case 5: //bSuitorBPQ(&G,b[0],nlocks,S,start,end,mark,order,4,stepM,St,opts.verbose);
                break;

        case 6: //bSuitorBPQD(&G,b,nlocks,S,start,end,mark,order,1,stepM,St,opts.verbose);
                break;

        case 7: //bSuitorBPQD(&G,b,nlocks,S,start,end,mark,order,2,stepM,St,opts.verbose);
                break;

        case 8: //cout<<"Calling Matching Code.."<<endl;
                bSuitorBPQD(&G,b,nlocks,S,start,end,stepM,sVer,npart, opts.nsort,opts.verbose);
                break;

        case 9: //PGDP(&G,S,b,W,start,opts.verbose);
                break;

    }
    
    /***************************************************/

    //_mm_free(nlocks);
    //_mm_free(end); 
    //_mm_free(start);
    //_mm_free(S);
    
    MCSR M;

    if(!opts.verbose)
    {
        if(rank==0)
        {    
            t1=omp_get_wtime()-t1;
            cout<<"Total Matching Time: "<<t1<<endl;
        }
        
    }
    else
    {

        if(rank==0)
        {    
            
            t1=omp_get_wtime()-t1;
            cout<<"Total Matching Time: "<<t1<<endl;
            
            
            /*************** Gathering Matching *******/
                
            /*M.nVer=G.gnVer;
            M.verPtr=(long long*)_mm_malloc((M.nVer+1)*sizeof(long long),64);
            M.verPtr[0]=0;
            MPI_Status treq;
            long long tstart=G.endNode+1, index=0;
            long long* sum=(long long*)_mm_malloc(G.nProc*sizeof(long long),64);
            
            // Create Process 0 per vertex matching cardinality
            sum[0]=0;
            index=1;
            for(long long i=G.startNode;i<=G.endNode;i++)
            {   
                M.verPtr[index]=S[i].curSize;
                sum[0]+=start[index];
                index++;
            }
            
            // Get per vertex matching cardinalty from others
            for(int i=1;i<G.nProc;i++)
            {
                MPI_Recv(&M.verPtr[index],G.nPerProc,MPI_LONG_LONG,i,12,MPI_COMM_WORLD,&treq);
                
                sum[i]=0;
                for(long long j=0;j<G.nPerProc;j++)
                    sum[i]+=M.verPtr[index+j];
                    
                index+=G.nPerProc;
            }

            
            // Build matching vertex pointer
            for(long long i=1;i<=M.nVer;i++)
                M.verPtr[i]=M.verPtr[i-1]+M.verPtr[i];
            
            M.nEdge=M.verPtr[M.nVer];
            
            M.verInd=(long long*)_mm_malloc(M.nEdge*sizeof(long long),64);
            M.verWt=(float*)_mm_malloc(M.nEdge*sizeof(float),64);
            
            // Create vertex Indices and weight for process 0
            index=0;
            for(long long i=G.startNode;i<=G.endNode;i++)
            {
                for(long long j=0;j<S[i].curSize;j++)
                {
                    M.verInd[index]=S[i].heap[j].id;
                    M.verWt[index]=S[i].heap[j].weight;
                    index++;
                }
            }

            // Get Vertex indices and weight from others
            for(int i=1;i<G.nProc;i++)
            {
                MPI_Recv(&M.verInd[index],sum[i],MPI_LONG_LONG,i,12,MPI_COMM_WORLD,&treq);
                MPI_Recv(&M.verWt[index],sum[i],MPI_FLOAT,i,12,MPI_COMM_WORLD,&treq);
                index+=sum[i];
            }
            
            

            if(verifyMatching(&M))
                cout<<"Matching Verified..!!"<<endl;
            else
                cout<<"We are Screwed..!!"<<endl; */
        }
        else
        {
            /************* Send Local Matching *****/
            
            /*MPI_Status treq;
            long long sum=0,indx=0;
            for(long long i=G.startNode;i<=G.endNode;i++)
            {   
                start[indx]=S[i].curSize;
                sum+=start[indx];
                indx++;
            }
            
            MPI_Send(&start[0],G.nVer,MPI_LONG_LONG,0,12,MPI_COMM_WORLD);
            

            long long* id=(long long*)_mm_malloc(sum*sizeof(long long),64);
            float* wt=(float*)_mm_malloc(sum*sizeof(float),64);

            indx=0;
            for(long long i=G.startNode;i<=G.endNode;i++)
            {
                for(long long j=0;j<S[i].curSize;j++)
                {
                    id[indx]=S[i].heap[j].id;
                    wt[indx]=S[i].heap[j].weight;
                    indx++;
                }
            }

            if(indx==sum)
            {
                MPI_Send(&id[0],sum,MPI_LONG_LONG,0,12,MPI_COMM_WORLD);
                MPI_Send(&wt[0],sum,MPI_FLOAT,0,12,MPI_COMM_WORLD);
            }
            else
                cout<<"Local Matching Send Error..!!"<<endl;
            
            _mm_free(id);
            _mm_free(wt);
            //free DCSR;
            */
        }
    }
   

    MPI_Finalize();    
    return 0;
}
