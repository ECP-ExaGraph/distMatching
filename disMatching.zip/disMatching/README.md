This is a distributed memory implementation of a half-approximation algorithm, b-Suitor, for computing a b-Matching of maximum weight in a graph with weights on the edges. b-Matching is a generalization of the 
well-known Matching problem in graphs, where the objective is to choose a subset of M edges in the 
graph such that at most a specified number b(v) of edges in M are incident on each vertex v. Subject
to this restriction we maximize the sum of the weights of the edges in M.

CITATION: 

Arif Khan, Alex Pothen, Mostofa Patwary, Mahantesh Halappanavar, Nadathur Satish, Narayanan Sunderam, Pradeep Dubey. "Computing b-Matchings to Scale on Distributed Memory Multiprocessors by Approximation." The International Conference for High Performance computing, Network, Storage and Analysis (Super Computing), 2016

CONTACT:

Arif Khan,    			ariful.khan@pnnl.gov
Alex Pothen, 			apothen@purdue.edu
Mahantesh Halappanavar,	hala@pnnl.gov


TO COMPILE:

Make

INPUT:

The implementation accepts two inputs: 
i) a graph G in MATRIX MARKET FORMAT (.mtx) and 
ii) EITHER 
    a file that has n lines where n is the number of vertices in G. The i th lines contains
    a single integer representing the b value of i th vertex, i.e., b[i] value. 
    OR
    a constant b for all vertices. if b=0 then the 
    code generates b-value for each vertex v, randomly between 1 and sqrt(d(v)), 
    where d(v) is the degree of v. 

OUTPUT:

For each vertex v, a priority queue holds the final matching. 
The user are requested look into bMatching.h for the priority queue data structure, called NODE. 
An example of the implementation is included in the main function in bMatching.cpp.

HELP:

./bMatching -h 

will show the input argument for the code as follows:

Usage:  -f <problemname> -e <bfilename> -b <bval> -a <algorithm> -v -g

        -f problemname  : file containing graph. Currently inputs .mtx files
        -e bfilename    : Optional input. (currently not implemented)
        -b bval         : constant b value if b=0 then randomly generated.
        -a algorithm    : Algorithm 0:unsorted 1:partial sorted mode (defualt)
        -t              : bipartite graph 
        -v              : verbose
