
// ***********************************************************************
//
//            Vite: A C++ library for distributed-memory graph b-Matching 
//                  using MPI-OpenMP
// 
//               Arif Khan (ariful.khan@pnnl.gov)
//               Mahantesh Halappanavar (hala@pnnl.gov)
//               Pacific Northwest National Laboratory       
//
//               Alex Pothen (apothen@purdue.edu)
//               Purdue University
//
// ***********************************************************************
//
//       Copyright (2017) Battelle Memorial Institute
//                      All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
// 1. Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
// COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
// BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
// ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// ************************************************************************
 
#include "mtxReader.h"
using namespace std;

/*bool CSR::readMtxB(char* filename)
{
    int count=0,i,j;
    int inp, m1, sym, edgecnt_;
    int numRow, numCol, nonZeros, numEdges;
    double f;
    string s;
    ifstream inf;

    inf.open(filename, ios::in);

    if(inf.is_open())
    {
        size_t found1, found2, found3;
        getline(inf,s);
        found1 = s.find("pattern");
        if (found1 != string::npos)
            m1 = 2;
        else
            m1 = 3;
        found1 = s.find("symmetric");
        found2 = s.find("hermitian");
        found3 = s.find("skew-symmetric");
        if (found1 != string::npos || found2 != string::npos || found3 != string::npos)
            sym = 1;
        else
            sym = 0;
        while(inf.peek()=='%')
            getline(inf,s);
 
        inf>>inp;
        numRow=inp;
        inf>>inp;
        numCol=inp;
        inf>>inp;
        nonZeros=inp;

        bipartite=true;
        nVer=numRow+numCol;
        sVer=numRow;

        count=inp;
        
        vector<vector<int> > graphCRSIdx(nVer);
        vector<vector<double> > graphCRSVal(nVer);
        int diag=0;
        
        while(count>0) 
        {     
            inf>>i; 
            inf>>j;

            j+=sVer; //adjusting for the right hand vertices
            
            if(m1==3) 
                inf>>f; 
            else
                f=1.0;

            if(i==j)
                diag++;
            else
            {
                graphCRSIdx[i-1].push_back(j-1); 
                graphCRSVal[i-1].push_back(f);
                if(sym) 
                {     
                    graphCRSIdx[j-1].push_back(i-1); 
                    graphCRSVal[j-1].push_back(f); 
                } 
            }   
            count--; 
        }     
        inf.close(); 
     
        numEdges = nonZeros;  
        if(sym == 1) //symmetric matrix 
            numEdges = nonZeros*2 - 2*diag; 
     
        nEdge=numEdges;
        
        verPtr=new int[nVer+1];
        verInd=new Edge[nEdge];

        verPtr[0]=0;
        int max=0,offset; 
        for(int i=1;i<=nVer;i++)
        {
            offset=graphCRSIdx[i-1].size();
            verPtr[i]=verPtr[i-1]+offset;
            count=verPtr[i-1];
            //cout<<i-1<<" "<<verPtr[i-1]<<" "<<verPtr[i]<<": ";
            for(int j=0;j<offset;j++)
            {
                verInd[count].id=graphCRSIdx[i-1][j];
                verInd[count].weight=graphCRSVal[i-1][j];
                count++;

                //cout<<verInd[count-1]<<" ";
            }
            //cout<<endl;
            if(offset>max)
                max=offset;
        }
        
        assert(count==nEdge);
        maxDeg=max;

    }
    else return false;
   
   return true;
}

bool CSR::readMtxG(char* filename)
{
    int count=0,i,j;
    int inp, m1, sym, edgecnt_;
    int numRow, numCol, nonZeros, numEdges;
    double f;
    string s;
    ifstream inf;

    inf.open(filename, ios::in);

    if(inf.is_open())
    {
        size_t found1, found2, found3;
        getline(inf,s);
        found1 = s.find("pattern");
        if (found1 != string::npos)
            m1 = 2;
        else
            m1 = 3;
        found1 = s.find("symmetric");
        found2 = s.find("hermitian");
        found3 = s.find("skew-symmetric");
        if (found1 != string::npos || found2 != string::npos || found3 != string::npos)
            sym = 1;
        else
            sym = 0;
        while(inf.peek()=='%')
            getline(inf,s);
 
        inf>>inp;
        numRow=inp;
        inf>>inp;
        numCol=inp;
        inf>>inp;
        nonZeros=inp;

        if(numRow==numCol)
            bipartite=false;
        else
            return false;

        count=inp;
        
        vector<vector<int> > graphCRSIdx(numRow);
        vector<vector<double> > graphCRSVal(numRow);
        int diag=0;
        
        while(count>0) 
        {     
            inf>>i; 
            inf>>j; 
            if(m1==3) 
                inf>>f; 
            else
                f=1.0;

            if(i==j)
                diag++;
            else
            {
                graphCRSIdx[i-1].push_back(j-1); 
                graphCRSVal[i-1].push_back(f);
                if(sym) 
                {     
                    graphCRSIdx[j-1].push_back(i-1); 
                    graphCRSVal[j-1].push_back(f); 
                } 
            }   
            count--; 
        }     
        inf.close(); 
     
        numEdges = nonZeros;  
        if(sym == 1) //symmetric matrix 
            numEdges = nonZeros*2 - 2*diag; 
     
        nVer=numRow; 
        sVer=0;
        nEdge=numEdges;
        
        verPtr=new int[nVer+1];
        verInd=new Edge[nEdge];

        verPtr[0]=0;
        int max=0,offset; 
        for(int i=1;i<=nVer;i++)
        {
            offset=graphCRSIdx[i-1].size();
            verPtr[i]=verPtr[i-1]+offset;
            count=verPtr[i-1];
            //cout<<i-1<<" "<<verPtr[i-1]<<" "<<verPtr[i]<<": ";
            for(int j=0;j<offset;j++)
            {
                verInd[count].id=graphCRSIdx[i-1][j];
                verInd[count].weight=graphCRSVal[i-1][j];
                count++;

                //cout<<verInd[count-1]<<" ";
            }
            //cout<<endl;
            if(offset>max)
                max=offset;
        }
        
        assert(count==nEdge);
        maxDeg=max;

    }
    else return false;
   
   return true;
}

bool CSR::mtxB2csrbin(char* filename, char* outfile)
{
    int count=0,i,j;
    int inp, m1, sym, edgecnt_;
    int numRow, numCol, nonZeros, numEdges;
    double f;
    string s;
    ifstream inf;

    inf.open(filename, ios::in);

    if(inf.is_open())
    {
        size_t found1, found2, found3;
        getline(inf,s);
        found1 = s.find("pattern");
        if (found1 != string::npos)
            m1 = 2;
        else
            m1 = 3;
        found1 = s.find("symmetric");
        found2 = s.find("hermitian");
        found3 = s.find("skew-symmetric");
        if (found1 != string::npos || found2 != string::npos || found3 != string::npos)
            sym = 1;
        else
            sym = 0;
        while(inf.peek()=='%')
            getline(inf,s);
 
        inf>>inp;
        numRow=inp;
        inf>>inp;
        numCol=inp;
        inf>>inp;
        nonZeros=inp;

        bipartite=false;
        nVer=numRow+numCol;
        sVer=numRow;
        count=inp;
 
        vector<vector<int> > graphCRSIdx(nVer);
        vector<vector<double> > graphCRSVal(nVer);
        int diag=0;
	    
        while(count>0) 
        {     
            inf>>i; 
            inf>>j; 
            j+=sVer; // Adjust for right hand side of biaprtite graph

            if(m1==3) 
                inf>>f; 
            else
                f=1.0;

            if(i==j)
                diag++;
            else
            {
                graphCRSIdx[i-1].push_back(j-1); 
                graphCRSVal[i-1].push_back(f);
                if(sym) 
                {     
                    graphCRSIdx[j-1].push_back(i-1); 
                    graphCRSVal[j-1].push_back(f); 
                } 
            }   
            count--; 
        }  
        inf.close(); 
 
     
        numEdges = nonZeros;  
        if(sym == 1) //symmetric matrix 
            numEdges = nonZeros*2 - 2*diag; 
     
        nEdge=numEdges;
    
        int* _verPtr=new int[nVer+1];
        int* _verInd=new int[nEdge];
        double* _verWt=new double[nEdge];

        _verPtr[0]=0;
        int max=0,offset;
        for(int i=1;i<=nVer;i++)
        {
            offset=graphCRSIdx[i-1].size();
            _verPtr[i]=_verPtr[i-1]+offset;
            count=_verPtr[i-1];
            //cout<<i-1<<" "<<verPtr[i-1]<<" "<<verPtr[i]<<": ";
            for(int j=0;j<offset;j++)
            {
                _verInd[count]=graphCRSIdx[i-1][j];
                _verWt[count]=graphCRSVal[i-1][j];
                count++;

                //cout<<verInd[count-1]<<" ";
            }
            //cout<<endl;
            if(offset>max)
                max=offset;
        }
        
        assert(count==nEdge);

        ///////////////// reading and csr format done //////////////
        // So write as binary file
        
        ofstream of;
        of.open(outfile,ios::out|ios::binary);
        of.write((char*)&nVer, sizeof(int));
        of.write((char*)&sVer, sizeof(int));
        of.write((char*)&nEdge, sizeof(int));
        of.write((char*)&max, sizeof(int));
        of.write((char*)&_verPtr[0], sizeof(int) * (nVer+1));
        of.write((char*)&_verInd[0], sizeof(int) * nEdge);
        of.write((char*)&_verWt[0], sizeof(double) * nEdge);
        of.close();
    }
    return true;
}

bool CSR::mtxG2csrbin(char* filename, char* outfile)
{
    int count=0,i,j;
    int inp, m1, sym, edgecnt_;
    int numRow, numCol, nonZeros, numEdges;
    double f;
    string s;
    ifstream inf;

    inf.open(filename, ios::in);

    if(inf.is_open())
    {
        size_t found1, found2, found3;
        getline(inf,s);
        found1 = s.find("pattern");
        if (found1 != string::npos)
            m1 = 2;
        else
            m1 = 3;
        found1 = s.find("symmetric");
        found2 = s.find("hermitian");
        found3 = s.find("skew-symmetric");
        if (found1 != string::npos || found2 != string::npos || found3 != string::npos)
            sym = 1;
        else
            sym = 0;
        while(inf.peek()=='%')
            getline(inf,s);
 
        inf>>inp;
        numRow=inp;
        inf>>inp;
        numCol=inp;
        inf>>inp;
        nonZeros=inp;

        if(numRow==numCol)
            bipartite=false;
        else return false;
 
        count=inp;
 
 
        vector<vector<int> > graphCRSIdx(numRow);
        vector<vector<double> > graphCRSVal(numRow);
        int diag=0;
	    
        while(count>0) 
        {     
            inf>>i; 
            inf>>j; 
            if(m1==3) 
                inf>>f; 
            else
                f=1.0;

            if(i==j)
                diag++;
            else
            {
                graphCRSIdx[i-1].push_back(j-1); 
                graphCRSVal[i-1].push_back(f);
                if(sym) 
                {     
                    graphCRSIdx[j-1].push_back(i-1); 
                    graphCRSVal[j-1].push_back(f); 
                } 
            }   
            count--; 
        }  
        inf.close(); 
 
     
        numEdges = nonZeros;  
        if(sym == 1) //symmetric matrix 
            numEdges = nonZeros*2 - 2*diag; 
     
     
        nVer=numRow; 
        nEdge=numEdges;
    
        int* _verPtr=new int[nVer+1];
        int* _verInd=new int[nEdge];
        double* _verWt=new double[nEdge];

        _verPtr[0]=0;
        int max=0,offset;
        for(int i=1;i<=nVer;i++)
        {
            offset=graphCRSIdx[i-1].size();
            _verPtr[i]=_verPtr[i-1]+offset;
            count=_verPtr[i-1];
            //cout<<i-1<<" "<<verPtr[i-1]<<" "<<verPtr[i]<<": ";
            for(int j=0;j<offset;j++)
            {
                _verInd[count]=graphCRSIdx[i-1][j];
                _verWt[count]=graphCRSVal[i-1][j];
                count++;

                //cout<<verInd[count-1]<<" ";
            }
            //cout<<endl;
            if(offset>max)
                max=offset;
        }
        
        assert(count==nEdge);

        ///////////////// reading and csr format done //////////////
        // So write as binary file
        
        ofstream of;
        of.open(outfile,ios::out|ios::binary);
        of.write((char*)&nVer, sizeof(int));
        of.write((char*)&sVer, sizeof(int));
        of.write((char*)&nEdge, sizeof(int));
        of.write((char*)&max, sizeof(int));
        of.write((char*)&_verPtr[0], sizeof(int) * (nVer+1));
        of.write((char*)&_verInd[0], sizeof(int) * nEdge);
        of.write((char*)&_verWt[0], sizeof(double) * nEdge);
        of.close();
    }
    return true;
}

bool CSR::readCSRbin(char* filename)
{
    ifstream inf;
    inf.open(filename,ios::in|ios::binary);
    if(inf.is_open())
    {
        inf.read((char*)&nVer,sizeof(int));
        //inf.read((char*)&sVer,sizeof(int)); // for General Graph sVer=0
        inf.read((char*)&nEdge,sizeof(int));
        inf.read((char*)&maxDeg,sizeof(int)); 
        verPtr=(int*)_mm_malloc((nVer+1)*sizeof(int),64);
        verInd=(Edge*)_mm_malloc(nEdge*sizeof(Edge),64);
        
        int* _verInd=(int*)_mm_malloc(nEdge*sizeof(int),64);
        double* _verWt=(double*)_mm_malloc(nEdge*sizeof(double),64);

        inf.read((char*)&verPtr[0],sizeof(int)*(nVer+1));
        inf.read((char*)&_verInd[0],sizeof(int)*nEdge);
        inf.read((char*)&_verWt[0],sizeof(double)*nEdge);
        inf.close();
        
        
        
        #pragma omp parallel for schedule(dynamic,64)
        for(int i=0;i<nEdge;i++)
        {
            verInd[i].id=_verInd[i];
            verInd[i].weight=(float)_verWt[i];
        }

        _mm_free(_verInd);
        _mm_free(_verWt);
        return true;
    }
    else
    return false;

}*/

/************ TCSR funtions **********/
bool TCSR::readCSRbin(char* filename)
{
    ifstream inf;
    inf.open(filename,ios::in|ios::binary);
    if(inf.is_open())
    {
        inf.read((char*)&nVer,sizeof(long long));
        //inf.read((char*)&sVer,sizeof(int)); // for General Graph sVer=0
        inf.read((char*)&nEdge,sizeof(long long));
        inf.read((char*)&maxDeg,sizeof(long long)); 
        verPtr=(long long*)_mm_malloc((nVer+1)*sizeof(long long),64);
        
        verInd=(long long*)_mm_malloc(nEdge*sizeof(long long),64);
        verWt=(float*)_mm_malloc(nEdge*sizeof(float),64);

        inf.read((char*)&verPtr[0],sizeof(long long)*(nVer+1));
        inf.read((char*)&verInd[0],sizeof(long long)*nEdge);
        inf.read((char*)&verWt[0],sizeof(float)*nEdge);
        inf.close();

        return true;
    }
    else
        return false;

}
