
// ***********************************************************************
//
//            Vite: A C++ library for distributed-memory graph b-Matching 
//                  using MPI-OpenMP
// 
//               Arif Khan (ariful.khan@pnnl.gov)
//               Mahantesh Halappanavar (hala@pnnl.gov)
//               Pacific Northwest National Laboratory       
//
//               Alex Pothen (apothen@purdue.edu)
//               Purdue University
//
// ***********************************************************************
//
//       Copyright (2017) Battelle Memorial Institute
//                      All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
// 1. Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
// COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
// BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
// ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// ************************************************************************
 
#ifndef BMATCHING_H
#define BMATCHING_H

#include <omp.h>
#include <mpi.h>
#include <cmath>
#include <iostream>
#include "mtxReader.h"
#include "pcl_stack.h"
//#include <immintrin.h>
#include <getopt.h>
#include "mic_utils.h"
using namespace std;

#define CHUNK 64
#define DYN
#define BSIZE 256
#define LBUF

struct Param
{
    int cstart;
    int cend;
    int ostart;
    int oend;
};

struct Info
{
    long long id;
    float weight;
};

struct Info1
{
    long long id;
    float weight;
};
class Node 
{
    public:
    long maxSize;
    long curSize;
    Info* heap;
    Info1 minEntry;

    void print();
    __forceinline long long min_id()
    {
        return (curSize>0 && curSize==maxSize)?heap[0].id:-1;
    }

    __forceinline  float min_weight()
    {
        return (curSize>0 && curSize==maxSize)?heap[0].weight:0.0;
    }

    __forceinline long find_id(long long idx)
    {
        for(long i=0;i<curSize;i++)
            if(heap[i].id==idx)
                return 1;
        return 0;
    }

    void Add(float wt, long long id);
    void AddHeap(float wt, long long id);
    
};

struct Walker
{
    int midx1;
    int midx2;
    float W1;
    float W2;
    float* M1;
    float* M2;
};
//Edge gEdge;

//void bSuitorBPQ(DCSR* G, int b, int *nlocks, Node* S, int* start, int* end, char* mark, int* order, int type, int stepM, stack_pcl<Param>*St, bool verbose);
//void b2Suitor(DCSR* G, int b, int *nlocks, Node* S, int* start, int* end, char* mark, int* order, int type);
//void bSuitorBPQD(DCSR* G, int b, int *nlocks, Node* S, int* start, int* end, char* mark, int* order, int type, int stepM, stack_pcl<Param>* St, bool verbose);
void bSuitorBPQD(DCSR* G, long long *b, int *nlocks, Node* S, long long* start, 
        long long* end, long long stepM, long long* sVer, long long npart, bool nsort,  bool verbose);
//int greedySerial(DCSR* G, Node* S, Node* S1, int *b, float* M, char* mark, int* curDeg);
//void localDomSerial(DCSR* G, Node* S, int* b, int* alive);
//double PGDP(DCSR* G, Node* S, int* b, Walker* W, int* mark,bool verbose);

bool comparator(Edge left, Edge right);
bool predicate(Edge left);
long long custom_sort(Edge* verInd, long long start, long long end, 
        long long step);

//int custom_sort_optimized(Edge* verInd, int start, int end, int part, int* order, int type, Edge* neighbors);

bool verifyMatching(DCSR* g, Node* S, long long n);
void printMatching(Node* S, long long n);

bool comparator(Edge left, Edge right);

struct bmatching_parameters
{
    char* problemname;
    char* bFileName;
    int b;
    int algorithm;
    int step;
    int sstep;
    int nstep;
    bool nsort;
    bool verbose;
    bool hybrid;

    bmatching_parameters();
    void usage();
    bool parse(int argc, char** argv);

};

#endif //BMATCHING_H
